<h1>
IF2150 REKAYASA PERANGKAT LUNAK
<br>
TUGAS 10
<br>
HASIL IMPLEMENTASI DAN UJI PERANGKAT LUNAK (HIUPL)
</h1>
<br>

## Kerja-In

<p align="center"><img alt="Logo Kerja-In" src="../M7/assets/logo.jpeg" width="240"></p>

### Untuk: Agatha Tatianingseto

Dipersiapkan oleh:
| Informasi | Keterangan |
| --- | --- |
| Kelas | 03 |
| Kelompok | 06 — Shifu |

| NIM | Nama |
| --- | --- |
| 13525033 | Davin Farel Santoso |
| 13525039 | Aditya Rasyid |
| 13525096 | Muhammad Ridwan Nasir Firdaus |
| 13525102 | Karmel Tua Haloho |
| 13525123 | Sebastio Nugroho |

---

## Daftar Isi

- [BAB 1: Pendahuluan](#bab-1-pendahuluan)
  - [1.1 Tujuan Penulisan Dokumen](#11-tujuan-penulisan-dokumen)
  - [1.2 Lingkup Masalah](#12-lingkup-masalah)
  - [1.3 Definisi, Istilah, dan Singkatan](#13-definisi-istilah-dan-singkatan)
  - [1.4 Aturan Penomoran](#14-aturan-penomoran)
  - [1.5 Referensi](#15-referensi)
  - [1.6 Deskripsi Umum Dokumen (Ikhtisar)](#16-deskripsi-umum-dokumen-ikhtisar)
- [BAB 2: Deskripsi Umum Perangkat Lunak](#bab-2-deskripsi-umum-perangkat-lunak)
- [BAB 3: Implementasi](#bab-3-implementasi)
  - [3.1 Lingkungan Implementasi](#31-lingkungan-implementasi)
  - [3.2 Implementasi Modul](#32-implementasi-modul)
  - [3.3 Implementasi Antarmuka](#33-implementasi-antarmuka)
  - [3.4 File Lain](#34-file-lain)
- [BAB 4: Hasil Pengujian](#bab-4-hasil-pengujian)
  - [4.1 Strategi dan Kedalaman Pengujian Kelas](#41-strategi-dan-kedalaman-pengujian-kelas)
  - [4.2 Pengujian Unit Kelas](#42-pengujian-unit-kelas)
  - [4.3 Pengujian Integrasi](#43-pengujian-integrasi)
  - [4.4 Pengujian Use Case](#44-pengujian-use-case)
  - [4.5 Pengujian Kebutuhan Non-Fungsional (KNF)](#45-pengujian-kebutuhan-non-fungsional-knf)
  - [4.6 Tangkapan Layar dan Bukti Hasil Pengujian](#46-tangkapan-layar-dan-bukti-hasil-pengujian)
- [BAB 5: Traceability](#bab-5-traceability)

---

## Daftar Perubahan

| Revisi | Deskripsi |
| :--- | :--- |
| | |

---

# BAB 1: Pendahuluan

## 1.1 Tujuan Penulisan Dokumen

Dokumen ini mencatat hasil implementasi dan pengujian Kerja-In sebagai acuan tim pengembang, dosen, dan asisten untuk menilai kesesuaian perangkat lunak dengan SKPL dan DPPL.

## 1.2 Lingkup Masalah

Kerja-In merupakan platform marketplace jasa berbasis web yang mempertemukan Penyedia Kerja dengan Tenaga Kerja sektor informal untuk mempermudah pencarian dan penyediaan pekerjaan harian. Aplikasi ini mendukung registrasi dan verifikasi identitas, pengelolaan lowongan, pengajuan penawaran, pemilihan tenaga kerja, pembayaran melalui Payment Gateway, penyerahan dan pemeriksaan hasil pekerjaan, serta pencairan upah. Rating, ulasan, dan portofolio membantu pengguna menilai reputasi tenaga kerja, sedangkan Customer Service membantu menangani keluhan dan sengketa terkait penggunaan platform.

## 1.3 Definisi, Istilah, dan Singkatan

Tabel 1.3. Definisi Istilah dan Singkatan

| Singkatan, Akronim, atau Istilah | Penjelasan |
| :--- | :--- |
| P/L | Singkatan dari Perangkat Lunak, yaitu aplikasi yang memberikan perintah kepada komputer untuk menjalankan tugas tertentu. |
| SKPL | Singkatan dari Spesifikasi Kebutuhan Perangkat Lunak, yaitu dokumen yang merangkum kriteria-kriteria yang diperlukan untuk membangun aplikasi menjalankan tugasnya. |
| DPPL | Singkatan dari Deskripsi Perancangan Perangkat Lunak, yaitu dokumen yang menjelaskan rancangan arsitektur, kelas, dan antarmuka P/L. |
| HIUPL | Singkatan dari Hasil Implementasi dan Uji Perangkat Lunak, yaitu dokumen yang melaporkan hasil implementasi dan pengujian P/L. |
| KF | Singkatan dari Kebutuhan Fungsional. |
| KNF | Singkatan dari Kebutuhan Non-Fungsional. |
| UC | Singkatan dari Use Case. |
| TC | Singkatan dari Test Case, yaitu satu kasus uji untuk skenario tertentu. |
| UT | Singkatan dari Unit Test, yaitu test case tingkat kelas/operasi. |
| INT | Singkatan dari Integration Test, yaitu test case yang menguji interaksi antarkomponen. |
| Boundary | Kasus uji pada nilai batas masukan, misalnya nilai minimum, maksimum, atau tepat di ambang aturan. |
| Coverage | Persentase baris/cabang kode yang dieksekusi oleh pengujian. |
| APL | Arsitektur Perangkat Lunak. |
| CS | Customer Service. |
| PK | Penyedia Kerja. |
| TK | Tenaga Kerja. |

## 1.4 Aturan Penomoran

Tabel 1.4. Aturan Penomoran

| Hal/Bagian | Penomoran | Keterangan |
| :--- | :--- | :--- |
| Kebutuhan Fungsional | KFXX | Sesuai SKPL |
| Kebutuhan Non-Fungsional | KNFXX | Sesuai SKPL |
| Use Case | UCXX | Sesuai SKPL |
| Kelas | CXX | Sesuai DPPL |
| Antarmuka | I-XX | Sesuai DPPL |
| Test Case Unit | CXX-UTYY | XX adalah nomor kelas, YY adalah nomor urut test case unit pada kelas tersebut |
| Test Case Integrasi | INT-TCYY | YY adalah nomor urut test case integrasi |
| Test Case Use Case | UCXX-TCYY | XX adalah nomor use case, YY adalah nomor urut test case pada use case tersebut |
| Test Case KNF | KNFXX-TCYY | XX adalah nomor KNF, YY adalah nomor urut test case pada KNF tersebut |
| Antarmuka integrasi | AI-XX | Nomor urut batas antarkomponen. |
| Algoritma | Algo-NNN | Sesuai DPPL2. |

## 1.5 Referensi

1. [SKPL (M5)](../M5/K03_G06_SKPL.md)
2. [APL (M6)](../M6/K03_G06_APL.md)
3. [DPPL2 (M8)](../M8/K03_G06_DPPL2.md)
4. [Laporan Implementasi (M9)](../M9/K03_G06_Implementasi.md)
5. [Panduan implementasi Kerja-In](../../src/README.md)
6. [Next.js](https://nextjs.org/docs), [React](https://react.dev/), [SQLite](https://sqlite.org/docs.html)
7. [Vitest](https://v2.vitest.dev/guide/), [Playwright](https://playwright.dev/docs/intro)
8. *Asistensi Akbar Tugas 10: Hasil Implementasi dan Uji Perangkat Lunak*, Laboratorium Rekayasa Perangkat Lunak IF2150.

## 1.6 Deskripsi Umum Dokumen (Ikhtisar)

Bab 1 memuat tujuan dan acuan. Bab 2 menggambarkan perangkat lunak. Bab 3 mencatat lingkungan, modul, antarmuka, dan file implementasi. Bab 4 melaporkan pengujian dan buktinya. Bab 5 memetakan kebutuhan ke implementasi dan test case.

<br>

---

# BAB 2: Deskripsi Umum Perangkat Lunak

Kerja-In mengelola akun, lowongan, pekerjaan, pembayaran, dan sengketa. Data dan berkas disimpan di SQLite dan penyimpanan aplikasi. Pembayaran dan pencairan disimulasikan oleh Payment Gateway dummy lokal.

```mermaid
flowchart LR
  Browser[Browser: TK, PK, CS] --> UI
  subgraph KI[Kerja-In]
    UI[Antarmuka Next.js] --> API[Route Handler dan Controller]
    API --> Model[Model]
    Model --> DB[(SQLite)]
    API --> File[(Penyimpanan berkas)]
    API --> Adapter[Adapter pembayaran]
    Adapter <-->|Permintaan dan callback simulasi| Mock[Payment Gateway dummy lokal]
  end
```

*Gambar 2.1. Batas sistem dan hubungan antarkomponen Kerja-In.*

<p align="center"><img alt="Use Case Diagram Kerja-In" src="../M5/assets/diagram/uc-diagram.jpg" width="90%"></p>

*Gambar 2.2. Use Case Diagram Kerja-In.*

Tenaga Kerja mencari pekerjaan dan menyerahkan hasil. Penyedia Kerja mengelola lowongan, memilih pelamar, membayar, dan memeriksa hasil. Customer Service memverifikasi identitas dan menangani sengketa.

<br>

---

# BAB 3: Implementasi

## 3.1 Lingkungan Implementasi

Tabel 3.1. Lingkungan Implementasi

| Aspek | Keterangan |
| :--- | :--- |
| Hardware | Intel Core Ultra 7 258V, RAM 32 GB |
| Operating System | Windows 11 (build 26200) |
| Bahasa Pemrograman | TypeScript 5.9.3, JavaScript, HTML, CSS, SQL |
| Framework/Library | Node.js 22.23.4, Next.js 15.5.29, React 19.1.0, Tailwind CSS 4.3.4, Zod 3.25.76 |
| DBMS | SQLite 3.49.2 melalui better-sqlite3 11.10.0 menggantikan PostgreSQL/Supabase dalam DPPL2. Sesi, autentikasi Argon2id, dan penyimpanan berkas dikelola oleh aplikasi. |
| Development Tools | Visual Studio Code, Git, npm |
| Testing Tools | Vitest 2.1.9, V8 Coverage, Playwright 1.64.1, Microsoft Edge, Chrome DevTools Protocol |

## 3.2 Implementasi Modul

Tabel 3.2. Implementasi Modul

| No | ID Kelas | Nama Modul/Kelas | Nama File Fisik | Nama File Executable |
| :--- | :--- | :--- | :--- | :--- |
| 1 | C01 | Pengguna | `src/models/Pengguna.ts`<br>`src/controllers/PenggunaController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 2 | C02 | TenagaKerja | `src/models/TenagaKerja.ts`<br>`src/controllers/TenagaKerjaController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 3 | C03 | PenyediaKerja | `src/db/migrations/0001_init.sql`<br>`src/controllers/LowonganPekerjaanController.ts`<br>`src/controllers/PengajuanPenawaranController.ts` | — |
| 4 | C04 | CustomerService | `src/controllers/CustomerServiceController.ts`<br>`src/controllers/TiketSengketaController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 5 | C05 | LowonganPekerjaan | `src/models/LowonganPekerjaan.ts`<br>`src/controllers/LowonganPekerjaanController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 6 | C06 | PengajuanPenawaran | `src/models/PengajuanPenawaran.ts`<br>`src/controllers/PengajuanPenawaranController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 7 | C07 | TransaksiPekerjaan | `src/models/TransaksiPekerjaan.ts`<br>`src/models/statusMachine.ts`<br>`src/controllers/TransaksiPekerjaanController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 8 | C08 | BuktiPenyerahan | `src/models/BuktiPenyerahan.ts`<br>`src/controllers/TransaksiBuktiController.ts`<br>`src/controllers/BerkasController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 9 | C09 | TagihanPembayaran | `src/models/TagihanPembayaran.ts`<br>`src/controllers/TagihanPembayaranController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 10 | C10 | PencairanDana | `src/models/PencairanDana.ts`<br>`src/controllers/DompetController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 11 | C11 | UlasanRating | `src/db/migrations/0001_init.sql`<br>`src/controllers/TransaksiPekerjaanController.ts`<br>`src/views/transaksi/FormUlasanTransaksi.tsx` | — |
| 12 | C12 | TiketSengketa | `src/models/TiketSengketa.ts`<br>`src/controllers/TiketSengketaController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 13 | C13 | RiwayatSengketa | `src/db/migrations/0001_init.sql`<br>`src/db/migrations/0002_immutability.sql`<br>`src/controllers/TiketSengketaController.ts` | — |
| 14 | C14 | Notifikasi | `src/models/Notifikasi.ts`<br>`src/controllers/NotifikasiController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 15 | C15 | PaymentGateway | `src/controllers/PaymentGatewayController.ts`<br>`src/controllers/MockGatewayController.ts`<br>`src/controllers/TagihanPembayaranController.ts`<br>`src/lib/payment/adapter.ts`<br>`src/lib/payment/mock.ts` | — |
| 16 | C16 | PenggunaUI | `src/app/daftar/page.tsx`<br>`src/app/masuk/page.tsx`<br>`src/views/AuthForm.tsx` | — |
| 17 | C17 | TenagaKerjaUI | `src/app/tk/page.tsx`<br>`src/app/tk/verifikasi/page.tsx`<br>`src/app/tk/lamaran/page.tsx`<br>`src/views/dompet/HalamanDompet.tsx` | — |
| 18 | C18 | PenyediaKerjaUI | `src/app/pk/page.tsx`<br>`src/app/pk/lowongan/page.tsx`<br>`src/app/pk/lowongan/pasang/page.tsx`<br>`src/app/pk/lowongan/[id]/page.tsx`<br>`src/app/pk/lowongan/[id]/pelamar/page.tsx` | — |
| 19 | C19 | CustomerServiceUI | `src/app/cs/page.tsx`<br>`src/app/cs/verifikasi/page.tsx`<br>`src/app/cs/tiket/page.tsx`<br>`src/app/cs/tiket/[id]/page.tsx` | — |
| 20 | C20 | LowonganPekerjaanUI | `src/app/lowongan/page.tsx`<br>`src/app/lowongan/[id]/page.tsx`<br>`src/app/pk/lowongan/page.tsx`<br>`src/app/pk/lowongan/pasang/page.tsx` | — |
| 21 | C21 | PengajuanPenawaranUI | `src/views/penawaran/DialogPenawaran.tsx`<br>`src/views/penawaran/DialogTarikPenawaran.tsx`<br>`src/views/penawaran/DaftarLamaran.tsx`<br>`src/app/tk/lamaran/page.tsx`<br>`src/app/pk/lowongan/[id]/pelamar/page.tsx` | — |
| 22 | C22 | TransaksiPekerjaanUI | `src/views/transaksi/HalamanDaftarTransaksi.tsx`<br>`src/views/transaksi/DetailTransaksi.tsx`<br>`src/app/pk/transaksi/[id]/page.tsx`<br>`src/app/tk/pekerjaan/[id]/page.tsx` | — |
| 23 | C23 | BuktiPenyerahanUI | `src/views/transaksi/DetailTransaksi.tsx`<br>`src/app/api/transaksi/[id]/bukti/route.ts` | — |
| 24 | C24 | TagihanPembayaranUI | `src/views/transaksi/TagihanPembayaranUI.tsx`<br>`src/app/pk/transaksi/[id]/bayar/page.tsx`<br>`src/app/mock-gateway/[idTagihan]/page.tsx` | — |
| 25 | C25 | PencairanDanaUI | `src/views/dompet/HalamanDompet.tsx`<br>`src/views/dompet/DompetUI.tsx` | — |
| 26 | C26 | UlasanRatingUI | `src/views/transaksi/FormUlasanTransaksi.tsx`<br>`src/app/tk/pekerjaan/[id]/ulasan/page.tsx`<br>`src/app/pk/transaksi/[id]/ulasan/page.tsx` | — |
| 27 | C27 | TiketSengketaUI | `src/app/tiket/[id]/page.tsx`<br>`src/app/cs/tiket/page.tsx`<br>`src/app/cs/tiket/[id]/page.tsx` | — |
| 28 | C28 | RiwayatSengketaUI | `src/app/tiket/[id]/page.tsx`<br>`src/app/cs/tiket/[id]/page.tsx` | — |
| 29 | C29 | NotifikasiUI | `src/views/NotificationBell.tsx` | — |
| 30 | C30 | PaymentGatewayUI | `src/views/MockGatewayUI.tsx`<br>`src/app/mock-gateway/[idTagihan]/page.tsx` | — |
| 31 | C31 | PenggunaController | `src/controllers/PenggunaController.ts` | — |
| 32 | C32 | TenagaKerjaController | `src/controllers/TenagaKerjaController.ts` | — |
| 33 | C33 | PenyediaKerjaController | `src/controllers/LowonganPekerjaanController.ts`<br>`src/controllers/PengajuanPenawaranController.ts` | — |
| 34 | C34 | CustomerServiceController | `src/controllers/CustomerServiceController.ts`<br>`src/controllers/TiketSengketaController.ts` | — |
| 35 | C35 | LowonganPekerjaanController | `src/controllers/LowonganPekerjaanController.ts` | — |
| 36 | C36 | PengajuanPenawaranController | `src/controllers/PengajuanPenawaranController.ts` | — |
| 37 | C37 | TransaksiPekerjaanController | `src/controllers/TransaksiPekerjaanController.ts` | — |
| 38 | C38 | BuktiPenyerahanController | `src/controllers/TransaksiBuktiController.ts`<br>`src/controllers/BerkasController.ts` | — |
| 39 | C39 | TagihanPembayaranController | `src/controllers/TagihanPembayaranController.ts` | — |
| 40 | C40 | PencairanDanaController | `src/controllers/DompetController.ts` | — |
| 41 | C41 | UlasanRatingController | `src/controllers/TransaksiPekerjaanController.ts` | — |
| 42 | C42 | TiketSengketaController | `src/controllers/TiketSengketaController.ts` | — |
| 43 | C43 | RiwayatSengketaController | `src/controllers/TiketSengketaController.ts`<br>`src/db/migrations/0001_init.sql` | — |
| 44 | C44 | NotifikasiController | `src/controllers/NotifikasiController.ts` | — |
| 45 | C45 | PaymentGatewayController | `src/controllers/PaymentGatewayController.ts`<br>`src/controllers/MockGatewayController.ts`<br>`src/app/api/webhooks/payment/route.ts` | — |

## 3.3 Implementasi Antarmuka

Tabel 3.3. Implementasi Antarmuka

| No | ID Antarmuka | Nama Antarmuka | Nama File Fisik | Nama File Executable |
| :--- | :--- | :--- | :--- | :--- |
| 1 | I-01 | [Beranda](./assets/layar/I-01.png) | `src/app/page.tsx` | — |
| 2 | I-02 | [Pencarian Pekerjaan](./assets/layar/UC04-TC01.png) | `src/app/lowongan/page.tsx` | — |
| 3 | I-03 | [Detail Pekerjaan](./assets/layar/UC05-TC02.png) | `src/app/lowongan/[id]/page.tsx` | — |
| 4 | I-04 | Formulir Penawaran | `src/views/penawaran/DialogPenawaran.tsx` | — |
| 5 | I-05 | [Tinjau Penawaran](./assets/layar/I-05.png) | `src/views/penawaran/DialogPenawaran.tsx` | — |
| 6 | I-06 | Pencarian Tenaga Kerja | Belum ada layar; endpoint tersedia | — |
| 7 | I-07 | [Profil Tenaga Kerja](./assets/layar/UC11-TC01.png) | `src/app/profil/[id]/page.tsx` | — |
| 8 | I-08 | [Masuk](./assets/layar/I-08.png) | `src/app/masuk/page.tsx` | — |
| 9 | I-09 | [Daftar Akun](./assets/layar/I-09.png) | `src/app/daftar/page.tsx` | — |
| 10 | I-10 | [Pemulihan Kata Sandi](./assets/layar/I-10.png) | `src/app/lupa-sandi/page.tsx` | — |
| 11 | I-11 | [Dashboard Tenaga Kerja](./assets/layar/I-11.png) | `src/app/tk/page.tsx` | — |
| 12 | I-12 | [Dashboard Penyedia Kerja](./assets/layar/I-12.png) | `src/app/pk/page.tsx` | — |
| 13 | I-13 | [Lamaran Saya](./assets/layar/I-13.png) | `src/app/tk/lamaran/page.tsx` | — |
| 14 | I-14 | [Pekerjaan Saya](./assets/layar/I-14.png) | `src/app/tk/[section]/page.tsx` | — |
| 15 | I-15 | [Lowongan Saya](./assets/layar/I-15.png) | `src/app/pk/lowongan/page.tsx` | — |
| 16 | I-16 | [Pasang Pekerjaan — Detail](./assets/layar/I-16.png) | `src/features/jobs/job-posting-wizard.tsx` | — |
| 17 | I-17 | Pasang Pekerjaan — Lokasi dan Jadwal | `src/features/jobs/job-posting-wizard.tsx` | — |
| 18 | I-18 | Pasang Pekerjaan — Upah dan Ketentuan | `src/features/jobs/job-posting-wizard.tsx` | — |
| 19 | I-19 | Pasang Pekerjaan — Tinjau dan Terbitkan | `src/features/jobs/job-posting-wizard.tsx` | — |
| 20 | I-20 | [Dompet](./assets/layar/UC10-TC01.png) | `src/views/dompet/HalamanDompet.tsx` | — |
| 21 | I-21 | [Pemeriksaan dan Transaksi](./assets/layar/UC08-TC01.png) | `src/views/transaksi/DetailTransaksi.tsx` | — |
| 22 | I-22 | [Pengaturan Profil Saya](./assets/layar/I-22.png) | `src/app/profil/page.tsx` | — |
| 23 | I-23 | [Pusat Bantuan dan Keluhan](./assets/layar/I-23.png) | `src/app/bantuan/page.tsx` | — |
| 24 | I-24 | [Kebijakan Privasi](./assets/layar/I-24.png) | `src/app/privasi/page.tsx` | — |
| 25 | I-25 | [Syarat dan Ketentuan](./assets/layar/I-25.png) | `src/app/syarat/page.tsx` | — |
| 26 | I-26 | Undangan Tenaga Kerja | Belum ada layar; endpoint tersedia | — |
| 27 | I-27 | Konfirmasi Penarikan Penawaran | `src/views/penawaran/DialogTarikPenawaran.tsx` | — |
| 28 | I-28 | [Halaman Tidak Ditemukan](./assets/layar/I-28.png) | `src/app/not-found.tsx` | — |
| 29 | I-29 | Permintaan Revisi Pekerjaan | `src/views/transaksi/DetailTransaksi.tsx` | — |

## 3.4 File Lain

Tabel 3.4. File Lain

| No | Nama File | Keterangan |
| :--- | :--- | :--- |
| 1 | `src/package.json` | Dependensi dan perintah aplikasi |
| 2 | `src/package-lock.json` | Versi dependensi terkunci |
| 3 | `src/.env.example` | Template konfigurasi aplikasi |
| 4 | `src/next.config.ts` | Konfigurasi Next.js |
| 5 | `src/middleware.ts` | Pemeriksaan permintaan aplikasi |
| 6 | `src/db/migrations/` | Skema, indeks, dan trigger SQLite |
| 7 | `src/db/seed.ts` | Data uji fiktif |
| 8 | `src/lib/db.ts` | Akses basis data dan transaksi |
| 9 | `src/lib/auth/` | Sesi, hash, dan pemeriksaan peran |
| 10 | `src/lib/storage.ts` | Validasi dan penyimpanan berkas |
| 11 | `src/lib/payment/` | Adapter dan simulator Payment Gateway dummy |
| 12 | `src/vitest.config.ts` | Konfigurasi uji unit dan integrasi |
| 13 | `src/playwright.config.ts` | Konfigurasi uji browser |
| 14 | `src/tests/unit/` | Uji unit |
| 15 | `src/tests/integration/` | Uji integrasi |
| 16 | `src/tests/e2e/` | Uji antarmuka browser |

<br>

---

# BAB 4: Hasil Pengujian

Pengujian lokal menggunakan snapshot `3ace3f4` dengan tambahan tiga kasus uji lokal (18 November 2026) karena tag M9 tidak tersedia pada salinan lokal. Vitest mencatat 487 kasus lulus dari 487 kasus pada 44 file.

## 4.1 Strategi dan Kedalaman Pengujian Kelas

Tabel 4.1.1. Identifikasi Tingkat Pengujian Kelas

| ID Kelas | Nama Kelas | Tingkat | Alasan | Test Case Terkait |
| :--- | :--- | :--- | :--- | :--- |
| C01 | Pengguna | Mendalam | Pembuatan akun atomik dan penolakan email ganda | C01-UT01, C01-UT02, C01-UT03, C01-UT04, C01-UT05, C01-UT06, C01-UT07, C01-UT08, C01-UT09, C01-UT10, C01-UT11, C01-UT12, C01-UT13, C01-UT14, C01-UT15, C01-UT16, C01-UT17, C01-UT18, C01-UT19, C01-UT20, C01-UT21, C01-UT22, C01-UT23, C01-UT24, INT-TC01, INT-TC02 |
| C02 | TenagaKerja | Mendalam | Aturan transisi verifikasi | INT-TC04, INT-TC05 |
| C03 | PenyediaKerja | Tidak perlu | Data peran berupa tabel, tanpa kelas domain terpisah | INT-TC01, INT-TC02 |
| C04 | CustomerService | Tidak perlu | Data peran berupa tabel, tanpa kelas domain terpisah | INT-TC04, INT-TC05 |
| C05 | LowonganPekerjaan | Mendalam | Status dan pencarian lowongan | INT-TC06, INT-TC07 |
| C06 | PengajuanPenawaran | Mendalam | Kuota dan perubahan status penawaran | INT-TC08, INT-TC09, INT-TC10 |
| C07 | TransaksiPekerjaan | Mendalam | Transisi status dan kredit upah | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12 |
| C08 | BuktiPenyerahan | Mendalam | Validasi dan penyimpanan bukti | C08-UT01, C08-UT02, C08-UT03, C08-UT04, C08-UT05, C08-UT06, C08-UT07, C08-UT08, C08-UT09, INT-TC14, INT-TC15 |
| C09 | TagihanPembayaran | Mendalam | Perhitungan komisi dan masa berlaku | INT-TC16, INT-TC19, INT-TC17 |
| C10 | PencairanDana | Mendalam | Transisi pencairan dan reservasi saldo | INT-TC22, INT-TC23, INT-TC24 |
| C11 | UlasanRating | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC25, INT-TC12 |
| C12 | TiketSengketa | Mendalam | Aturan status dan penyimpanan sengketa | INT-TC26, INT-TC27 |
| C13 | RiwayatSengketa | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC26, INT-TC27 |
| C14 | Notifikasi | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC29 |
| C15 | PaymentGateway | Mendalam | Adapter pembayaran dummy | C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13, INT-TC19, INT-TC20 |
| C16 | PenggunaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C17 | TenagaKerjaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C18 | PenyediaKerjaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C19 | CustomerServiceUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C20 | LowonganPekerjaanUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C21 | PengajuanPenawaranUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C22 | TransaksiPekerjaanUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C23 | BuktiPenyerahanUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C24 | TagihanPembayaranUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C25 | PencairanDanaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C26 | UlasanRatingUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C27 | TiketSengketaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C28 | RiwayatSengketaUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C29 | NotifikasiUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C30 | PaymentGatewayUI | Tidak perlu | Antarmuka React diuji melalui alur pengguna | — |
| C31 | PenggunaController | Mendalam | Validasi usia, kredensial dan autentikasi | INT-TC01, INT-TC02 |
| C32 | TenagaKerjaController | Mendalam | Validasi dokumen dan status pengajuan | INT-TC04, INT-TC05 |
| C33 | PenyediaKerjaController | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC06, INT-TC07 |
| C34 | CustomerServiceController | Mendalam | Otorisasi dan keputusan verifikasi | INT-TC04, INT-TC05 |
| C35 | LowonganPekerjaanController | Mendalam | Validasi lowongan dan aturan kategorisasi | INT-TC06, INT-TC07 |
| C36 | PengajuanPenawaranController | Mendalam | Otorisasi dan pemilihan pelamar | INT-TC08, INT-TC09, INT-TC10 |
| C37 | TransaksiPekerjaanController | Mendalam | Validasi perubahan status, kredit dan ulasan | INT-TC11, INT-TC12 |
| C38 | BuktiPenyerahanController | Mendalam | Otorisasi dan validasi bukti penyerahan | INT-TC14, INT-TC15 |
| C39 | TagihanPembayaranController | Mendalam | Pembuatan, pembayaran dan refund tagihan | INT-TC16, INT-TC19, INT-TC17 |
| C40 | PencairanDanaController | Mendalam | Validasi rekening, saldo dan pencairan ulang | C40-UT01, C40-UT02, C40-UT03, INT-TC22, INT-TC23, INT-TC24 |
| C41 | UlasanRatingController | Mendalam | Validasi dan pencegahan ulasan ganda | INT-TC25, INT-TC12 |
| C42 | TiketSengketaController | Mendalam | Otorisasi dan penanganan sengketa | INT-TC26, INT-TC27 |
| C43 | RiwayatSengketaController | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC26, INT-TC27 |
| C44 | NotifikasiController | Sedang | Pencatatan atau delegasi ke operasi domain | INT-TC29 |
| C45 | PaymentGatewayController | Mendalam | Verifikasi dan pemrosesan callback pembayaran dummy | INT-TC19, INT-TC20 |

## 4.2 Pengujian Unit Kelas

Jalankan `npm test -- tests/unit` dari `src`. Lokasi test `src/tests/unit/`. Cakupan V8 di bawah diukur dari seluruh suite unit dan integrasi, per file implementasi. Tabel kasus uji memuat kasus yang relevan dengan lingkup HIUPL.

### 4.2.1 Kelas Pengguna

**ID Kelas:** C01<br>
**Nama Kelas:** Pengguna<br>
**Tingkat:** Mendalam

Tabel 4.2.1. Hasil Pengujian Unit Kelas C01

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C01-UT01 | `validasiBatasUsia()` | Batas | sehari sebelum ulang tahun ke-17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT02 | `validasiBatasUsia()` | Batas | tepat ulang tahun ke-17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT03 | `validasiBatasUsia()` | Batas | sehari setelah ulang tahun ke-17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT04 | `validasiBatasUsia()` | Negatif | sebelum pergantian hari WIB | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT05 | `validasiBatasUsia()` | Batas | tepat tengah malam WIB | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT06 | `validasiBatasUsia()` | Normal | lahir 29 Feb: 28 Feb tahun nonkabisat masih 16 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT07 | `validasiBatasUsia()` | Normal | lahir 29 Feb: 1 Maret tahun nonkabisat sudah 17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT08 | `validasiBatasUsia()` | Normal | 29 Feb yang valid pada tahun kabisat | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT09 | `validasiBatasUsia()` | Batas | ulang tahun di 1 Januari, belum 17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT10 | `validasiBatasUsia()` | Batas | ulang tahun di 1 Januari, sudah 17 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT11 | `validasiBatasUsia()` | Normal | tahun 2000 kabisat | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT12 | `validasiBatasUsia()` | Normal | tahun 1900 bukan kabisat | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT13 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak:  | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT14 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: invalid | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT15 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2009-02-29 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT16 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2000-02-30 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT17 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2000-04-31 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT18 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2000-13-01 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT19 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2000-00-01 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT20 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2000-01-00 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT21 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 06-11-2009 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT22 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2009-1-1 | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT23 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2009-11-06T00:00:00Z | Asersi berhasil | Asersi berhasil | Pass |
| C01-UT24 | `validasiBatasUsia()` | Negatif | tanggal tidak valid/masa depan ditolak: 2027-01-01 | Asersi berhasil | Asersi berhasil | Pass |

Tabel 4.2.1b. Ringkasan Cakupan Kelas C01

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | registrasi, validasiUsia, login, generateToken, berikanUlasan |
| Operasi yang diuji | validasiBatasUsia() |
| ID Algoritma yang tercakup | Algo-001 |
| Coverage (target ≥ 70%) | `src/models/Pengguna.ts`: 100% baris / 100% cabang<br>`src/controllers/PenggunaController.ts`: 100% baris / 100% cabang<br>`src/lib/validation/auth.ts`: 100% baris / 100% cabang |

### 4.2.2 Kelas TenagaKerja

**ID Kelas:** C02<br>
**Nama Kelas:** TenagaKerja<br>
**Tingkat:** Mendalam

Tabel 4.2.2. Hasil Pengujian Unit Kelas C02

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC04, INT-TC05 | Belum ada uji unit khusus |

Tabel 4.2.2b. Ringkasan Cakupan Kelas C02

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | cariLowongan, filterLowongan, buatProfil, ajukanVerifikasi, perbaruiStatusVerifikasi, ajukanPenawaran, batalkanPengajuan, serahkanPekerjaan, terimaUpah, ajukanPencairan |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/TenagaKerja.ts`: 100% baris / 88.46% cabang<br>`src/controllers/TenagaKerjaController.ts`: 87.75% baris / 77.77% cabang |

### 4.2.3 Kelas LowonganPekerjaan

**ID Kelas:** C05<br>
**Nama Kelas:** LowonganPekerjaan<br>
**Tingkat:** Mendalam

Tabel 4.2.3. Hasil Pengujian Unit Kelas C05

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC06, INT-TC07 | Belum ada uji unit khusus |

Tabel 4.2.3b. Ringkasan Cakupan Kelas C05

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | simpanLowongan, tampilkanDaftarLowongan, cekStatusOpen, tampilkanTombolAjukan, cekKuotaSisa |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/LowonganPekerjaan.ts`: 100% baris / 97.5% cabang<br>`src/controllers/LowonganPekerjaanController.ts`: 88.23% baris / 93.75% cabang |

### 4.2.4 Kelas PengajuanPenawaran

**ID Kelas:** C06<br>
**Nama Kelas:** PengajuanPenawaran<br>
**Tingkat:** Mendalam

Tabel 4.2.4. Hasil Pengujian Unit Kelas C06

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC08, INT-TC09, INT-TC10 | Belum ada uji unit khusus |

Tabel 4.2.4b. Ringkasan Cakupan Kelas C06

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | simpanPengajuan, setStatusPersetujuan |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/PengajuanPenawaran.ts`: 100% baris / 97.56% cabang<br>`src/controllers/PengajuanPenawaranController.ts`: 88.8% baris / 95.23% cabang |

### 4.2.5 Kelas TransaksiPekerjaan

**ID Kelas:** C07<br>
**Nama Kelas:** TransaksiPekerjaan<br>
**Tingkat:** Mendalam

Tabel 4.2.5. Hasil Pengujian Unit Kelas C07

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C07-UT01 | `transisiDiizinkan()` | Negatif | pekerjaan: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT02 | `transisiDiizinkan()` | Negatif | pembayaran: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT03 | `transisiDiizinkan()` | Negatif | pencairan: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT04 | `transisiDiizinkan()` | Negatif | penawaran: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT05 | `transisiDiizinkan()` | Negatif | tiket: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT06 | `transisiDiizinkan()` | Negatif | verifikasi: seluruh pasangan valid diizinkan dan pasangan lainnya ditolak | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT07 | `transisiDiizinkan()` | Normal | pemulihan sengketa ke SUBMITTED dan IN_PROGRESS diizinkan | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT08 | `transisiDiizinkan()` | Negatif | pekerjaan selesai tidak dapat disengketakan dan tidak boleh melewati pembayaran | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT09 | `transisiDiizinkan()` | Normal | menolak transisi lintas jenis | Asersi berhasil | Asersi berhasil | Pass |
| C07-UT10 | `transisiDiizinkan()` | Normal | label pekerjaan sesuai §2.8 | Asersi berhasil | Asersi berhasil | Pass |

Tabel 4.2.5b. Ringkasan Cakupan Kelas C07

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | buatTransaksiBaru, verifikasiSelesai, picuPembayaranUpah, cekStatusSelesai, validasiUlasanGanda, getDetailTransaksi |
| Operasi yang diuji | transisiDiizinkan() |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/TransaksiPekerjaan.ts`: 99.69% baris / 72.05% cabang<br>`src/models/statusMachine.ts`: 100% baris / 80% cabang<br>`src/controllers/TransaksiPekerjaanController.ts`: 90.36% baris / 72.88% cabang |

### 4.2.6 Kelas BuktiPenyerahan

**ID Kelas:** C08<br>
**Nama Kelas:** BuktiPenyerahan<br>
**Tingkat:** Mendalam

Tabel 4.2.6. Hasil Pengujian Unit Kelas C08

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C08-UT01 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Normal | menyimpan PNG dengan nama UUID, bukan nama asli | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT02 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Normal | menolak .exe yang di-rename .jpg (magic bytes) | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT03 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Negatif | menolak MIME yang tidak cocok dengan isi | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT04 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Normal | menolak berkas kosong | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT05 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Batas | batas ukuran: identitas 5 MB, bukti 10 MB | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT06 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Negatif | isi di disk tidak terbaca, tetapi bacaBerkas mengembalikan aslinya | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT07 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Negatif | berkas yang diubah di disk gagal didekripsi (integritas GCM) | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT08 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Normal | menolak path traversal | Asersi berhasil | Asersi berhasil | Pass |
| C08-UT09 | `simpanBerkas() / bacaBerkas() / hapusBerkas()` | Normal | hapusBerkas menghapus dan idempoten | Asersi berhasil | Asersi berhasil | Pass |

Tabel 4.2.6b. Ringkasan Cakupan Kelas C08

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | validasiUkuranFile, simpanBukti |
| Operasi yang diuji | simpanBerkas() / bacaBerkas() / hapusBerkas() |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/BuktiPenyerahan.ts`: 100% baris / 100% cabang<br>`src/controllers/TransaksiBuktiController.ts`: 85.96% baris / 71.42% cabang<br>`src/controllers/BerkasController.ts`: 92.59% baris / 92.85% cabang<br>`src/lib/storage.ts`: 100% baris / 89.36% cabang |

### 4.2.7 Kelas TagihanPembayaran

**ID Kelas:** C09<br>
**Nama Kelas:** TagihanPembayaran<br>
**Tingkat:** Mendalam

Tabel 4.2.7. Hasil Pengujian Unit Kelas C09

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC16, INT-TC19, INT-TC17 | Belum ada uji unit khusus |

Tabel 4.2.7b. Ringkasan Cakupan Kelas C09

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | hitungTotalTagihan, buatInvoice |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/TagihanPembayaran.ts`: 90.9% baris / 84.61% cabang<br>`src/controllers/TagihanPembayaranController.ts`: 80.12% baris / 79.59% cabang |

### 4.2.8 Kelas PencairanDana

**ID Kelas:** C10<br>
**Nama Kelas:** PencairanDana<br>
**Tingkat:** Mendalam

Tabel 4.2.8. Hasil Pengujian Unit Kelas C10

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC22, INT-TC23, INT-TC24 | Belum ada uji unit khusus |

Tabel 4.2.8b. Ringkasan Cakupan Kelas C10

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | buatTransaksiPencairan, updateStatusPencairan |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/PencairanDana.ts`: 99.42% baris / 98.07% cabang<br>`src/controllers/DompetController.ts`: 74.28% baris / 86.66% cabang |

### 4.2.9 Kelas UlasanRating

**ID Kelas:** C11<br>
**Nama Kelas:** UlasanRating<br>
**Tingkat:** Sedang

Tabel 4.2.9. Hasil Pengujian Unit Kelas C11

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC25, INT-TC12 | Dilaporkan di 4.3 |

### 4.2.10 Kelas TiketSengketa

**ID Kelas:** C12<br>
**Nama Kelas:** TiketSengketa<br>
**Tingkat:** Mendalam

Tabel 4.2.10. Hasil Pengujian Unit Kelas C12

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC26, INT-TC27 | Belum ada uji unit khusus |

Tabel 4.2.10b. Ringkasan Cakupan Kelas C12

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | buatTiket, updateStatus |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/models/TiketSengketa.ts`: 100% baris / 90.47% cabang<br>`src/controllers/TiketSengketaController.ts`: 96.23% baris / 90.8% cabang |

### 4.2.11 Kelas RiwayatSengketa

**ID Kelas:** C13<br>
**Nama Kelas:** RiwayatSengketa<br>
**Tingkat:** Sedang

Tabel 4.2.11. Hasil Pengujian Unit Kelas C13

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC26, INT-TC27 | Dilaporkan di 4.3 |

### 4.2.12 Kelas Notifikasi

**ID Kelas:** C14<br>
**Nama Kelas:** Notifikasi<br>
**Tingkat:** Sedang

Tabel 4.2.12. Hasil Pengujian Unit Kelas C14

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC29 | Dilaporkan di 4.3 |

### 4.2.13 Kelas PaymentGateway

**ID Kelas:** C15<br>
**Nama Kelas:** PaymentGateway<br>
**Tingkat:** Mendalam

Tabel 4.2.13. Hasil Pengujian Unit Kelas C15

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C15-UT01 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | mengembalikan MockPaymentGateway jika env tidak diset atau 'mock' | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT04 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Negatif | melemparkan error jika provider tidak dikenal | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT05 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | charge(): mengembalikan URL redirect mock dan mencatat log jenis CHARGE | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT06 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | disburse(): mengembalikan status DITERIMA dan mencatat log jenis DISBURSEMENT | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT07 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | refund(): mengembalikan status BERHASIL dan meneruskan idempotency key pada log REFUND | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT08 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | memvalidasi signature yang sah dengan timingSafeEqual | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT09 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Negatif | menolak signature yang salah atau payload yang telah dimanipulasi | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT10 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Negatif | menolak jika signature memiliki panjang berbeda tanpa melempar error timingSafeEqual | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT11 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Negatif | menolak jika PAYMENT_WEBHOOK_SECRET tidak ada | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT12 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Normal | mencatat log dan mengambil kembali dengan format ISO | Asersi berhasil | Asersi berhasil | Pass |
| C15-UT13 | `getPaymentAdapter() / buatPembayaran() / buatPencairan()` | Negatif | menjaga sifat immutability (KNF20): tidak mengizinkan UPDATE atau DELETE pada log_gateway | Asersi berhasil | Asersi berhasil | Pass |

Tabel 4.2.13b. Ringkasan Cakupan Kelas C15

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | prosesPembayaran, dapatkanCallbackStatus, prosesTransferDana |
| Operasi yang diuji | getPaymentAdapter() / buatPembayaran() / buatPencairan() |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/PaymentGatewayController.ts`: 89.42% baris / 77.77% cabang<br>`src/controllers/MockGatewayController.ts`: 94.28% baris / 75% cabang<br>`src/controllers/TagihanPembayaranController.ts`: 80.12% baris / 79.59% cabang<br>`src/lib/payment/adapter.ts`: 100% baris / 100% cabang |

### 4.2.14 Kelas PenggunaController

**ID Kelas:** C31<br>
**Nama Kelas:** PenggunaController<br>
**Tingkat:** Mendalam

Tabel 4.2.14. Hasil Pengujian Unit Kelas C31

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC01, INT-TC02 | Belum ada uji unit khusus |

Tabel 4.2.14b. Ringkasan Cakupan Kelas C31

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/PenggunaController.ts`: 100% baris / 100% cabang |

### 4.2.15 Kelas TenagaKerjaController

**ID Kelas:** C32<br>
**Nama Kelas:** TenagaKerjaController<br>
**Tingkat:** Mendalam

Tabel 4.2.15. Hasil Pengujian Unit Kelas C32

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC04, INT-TC05 | Belum ada uji unit khusus |

Tabel 4.2.15b. Ringkasan Cakupan Kelas C32

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TenagaKerjaController.ts`: 87.75% baris / 77.77% cabang |

### 4.2.16 Kelas PenyediaKerjaController

**ID Kelas:** C33<br>
**Nama Kelas:** PenyediaKerjaController<br>
**Tingkat:** Sedang

Tabel 4.2.16. Hasil Pengujian Unit Kelas C33

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC06, INT-TC07 | Dilaporkan di 4.3 |

### 4.2.17 Kelas CustomerServiceController

**ID Kelas:** C34<br>
**Nama Kelas:** CustomerServiceController<br>
**Tingkat:** Mendalam

Tabel 4.2.17. Hasil Pengujian Unit Kelas C34

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC04, INT-TC05 | Belum ada uji unit khusus |

Tabel 4.2.17b. Ringkasan Cakupan Kelas C34

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/CustomerServiceController.ts`: 93.33% baris / 95.83% cabang<br>`src/controllers/TiketSengketaController.ts`: 96.23% baris / 90.8% cabang |

### 4.2.18 Kelas LowonganPekerjaanController

**ID Kelas:** C35<br>
**Nama Kelas:** LowonganPekerjaanController<br>
**Tingkat:** Mendalam

Tabel 4.2.18. Hasil Pengujian Unit Kelas C35

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC06, INT-TC07 | Belum ada uji unit khusus |

Tabel 4.2.18b. Ringkasan Cakupan Kelas C35

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/LowonganPekerjaanController.ts`: 88.23% baris / 93.75% cabang |

### 4.2.19 Kelas PengajuanPenawaranController

**ID Kelas:** C36<br>
**Nama Kelas:** PengajuanPenawaranController<br>
**Tingkat:** Mendalam

Tabel 4.2.19. Hasil Pengujian Unit Kelas C36

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC08, INT-TC09, INT-TC10 | Belum ada uji unit khusus |

Tabel 4.2.19b. Ringkasan Cakupan Kelas C36

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/PengajuanPenawaranController.ts`: 88.8% baris / 95.23% cabang |

### 4.2.20 Kelas TransaksiPekerjaanController

**ID Kelas:** C37<br>
**Nama Kelas:** TransaksiPekerjaanController<br>
**Tingkat:** Mendalam

Tabel 4.2.20. Hasil Pengujian Unit Kelas C37

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC11, INT-TC12 | Belum ada uji unit khusus |

Tabel 4.2.20b. Ringkasan Cakupan Kelas C37

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TransaksiPekerjaanController.ts`: 90.36% baris / 72.88% cabang |

### 4.2.21 Kelas BuktiPenyerahanController

**ID Kelas:** C38<br>
**Nama Kelas:** BuktiPenyerahanController<br>
**Tingkat:** Mendalam

Tabel 4.2.21. Hasil Pengujian Unit Kelas C38

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC14, INT-TC15 | Belum ada uji unit khusus |

Tabel 4.2.21b. Ringkasan Cakupan Kelas C38

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TransaksiBuktiController.ts`: 85.96% baris / 71.42% cabang<br>`src/controllers/BerkasController.ts`: 92.59% baris / 92.85% cabang |

### 4.2.22 Kelas TagihanPembayaranController

**ID Kelas:** C39<br>
**Nama Kelas:** TagihanPembayaranController<br>
**Tingkat:** Mendalam

Tabel 4.2.22. Hasil Pengujian Unit Kelas C39

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC16, INT-TC19, INT-TC17 | Belum ada uji unit khusus |

Tabel 4.2.22b. Ringkasan Cakupan Kelas C39

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TagihanPembayaranController.ts`: 80.12% baris / 79.59% cabang |

### 4.2.23 Kelas PencairanDanaController

**ID Kelas:** C40<br>
**Nama Kelas:** PencairanDanaController<br>
**Tingkat:** Mendalam

Tabel 4.2.23. Hasil Pengujian Unit Kelas C40

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C40-UT01 | `Enkripsi dan pembacaan rekening` | Normal | AES-GCM memakai nonce acak dan hanya dapat dibuka pada konteks asal | Asersi berhasil | Asersi berhasil | Pass |
| C40-UT02 | `Enkripsi dan pembacaan rekening` | Negatif | kunci hilang, tidak valid atau berubah ditolak tanpa fallback produksi | Asersi berhasil | Asersi berhasil | Pass |
| C40-UT03 | `Enkripsi dan pembacaan rekening` | Negatif | log nested disamarkan dan fingerprint stabil tidak memuat nomor rekening | Asersi berhasil | Asersi berhasil | Pass |

Tabel 4.2.23b. Ringkasan Cakupan Kelas C40

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | Enkripsi dan pembacaan rekening |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/DompetController.ts`: 74.28% baris / 86.66% cabang<br>`src/lib/rekening.ts`: 100% baris / 96.66% cabang |

### 4.2.24 Kelas UlasanRatingController

**ID Kelas:** C41<br>
**Nama Kelas:** UlasanRatingController<br>
**Tingkat:** Mendalam

Tabel 4.2.24. Hasil Pengujian Unit Kelas C41

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC25, INT-TC12 | Belum ada uji unit khusus |

Tabel 4.2.24b. Ringkasan Cakupan Kelas C41

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TransaksiPekerjaanController.ts`: 90.36% baris / 72.88% cabang |

### 4.2.25 Kelas TiketSengketaController

**ID Kelas:** C42<br>
**Nama Kelas:** TiketSengketaController<br>
**Tingkat:** Mendalam

Tabel 4.2.25. Hasil Pengujian Unit Kelas C42

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC26, INT-TC27 | Belum ada uji unit khusus |

Tabel 4.2.25b. Ringkasan Cakupan Kelas C42

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | — |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/TiketSengketaController.ts`: 96.23% baris / 90.8% cabang |

### 4.2.26 Kelas RiwayatSengketaController

**ID Kelas:** C43<br>
**Nama Kelas:** RiwayatSengketaController<br>
**Tingkat:** Sedang

Tabel 4.2.26. Hasil Pengujian Unit Kelas C43

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC26, INT-TC27 | Dilaporkan di 4.3 |

### 4.2.27 Kelas NotifikasiController

**ID Kelas:** C44<br>
**Nama Kelas:** NotifikasiController<br>
**Tingkat:** Sedang

Tabel 4.2.27. Hasil Pengujian Unit Kelas C44

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi: INT-TC29 | Dilaporkan di 4.3 |

### 4.2.28 Kelas PaymentGatewayController

**ID Kelas:** C45<br>
**Nama Kelas:** PaymentGatewayController<br>
**Tingkat:** Mendalam

Tabel 4.2.28. Hasil Pengujian Unit Kelas C45

| ID Pengujian | Operasi yang Diuji | Jenis Kasus | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| — | — | — | — | — | Uji integrasi callback dummy: INT-TC19, INT-TC20 | Belum ada uji unit khusus |

Tabel 4.2.28b. Ringkasan Cakupan Kelas C45

| Informasi | Keterangan |
| :--- | :--- |
| Daftar operasi public pada DPPL | Lihat Tabel 4.1 DPPL2 |
| Operasi yang diuji | Pemrosesan dan validasi callback dummy (INT-TC19, INT-TC20) |
| ID Algoritma yang tercakup | — |
| Coverage (target ≥ 70%) | `src/controllers/PaymentGatewayController.ts`: 89.42% baris / 77.77% cabang<br>`src/controllers/MockGatewayController.ts`: 94.28% baris / 75% cabang |

## 4.3 Pengujian Integrasi

Vitest menggunakan controller, model, dan SQLite uji. Sejumlah suite menggantikan akses cookie pada batas Next.js. Pengujian browser memakai sesi dan HTTP aplikasi. Integrasi pembayaran yang diuji memakai simulator lokal.

Tabel 4.3.1. Daftar Antarmuka Antarkomponen

| ID Antarmuka | Komponen Asal | Komponen Tujuan | Jenis Batas | Test Case |
| :--- | :--- | :--- | :--- | :--- |
| AI-01 | PenggunaController | Pengguna, autentikasi dan sesi | Controller – Model | INT-TC01, INT-TC02, INT-TC03 |
| AI-02 | TenagaKerjaController / CustomerServiceController | TenagaKerja dan penyimpanan berkas | Controller – Model – Berkas | INT-TC04, INT-TC05 |
| AI-03 | LowonganPekerjaanUI / LowonganPekerjaanController | LowonganPekerjaan | Route Handler – Controller – Model | INT-TC06, INT-TC07 |
| AI-04 | PengajuanPenawaranUI / PengajuanPenawaranController | PengajuanPenawaran dan LowonganPekerjaan | Route Handler – Controller – Model | INT-TC08, INT-TC09, INT-TC10 |
| AI-05 | TransaksiPekerjaanUI / TransaksiPekerjaanController | TransaksiPekerjaan | Route Handler – Controller – Model | INT-TC11, INT-TC12, INT-TC13 |
| AI-06 | TransaksiBuktiController / BerkasController | BuktiPenyerahan dan penyimpanan berkas | Controller – Model – Berkas | INT-TC14, INT-TC15 |
| AI-07 | TagihanPembayaranUI / TagihanPembayaranController | TagihanPembayaran | Controller – Model | INT-TC16, INT-TC17, INT-TC18 |
| AI-08 | TagihanPembayaranController / PaymentGatewayController | Simulator pembayaran dan callback | Aplikasi – simulator gateway | INT-TC19, INT-TC20 |
| AI-09 | DompetController / PaymentGatewayController | PencairanDana dan simulator pencairan | Controller – Model – simulator gateway | INT-TC21, INT-TC22, INT-TC23, INT-TC24 |
| AI-10 | UlasanRatingUI / TransaksiPekerjaanController | Ulasan dan Profil | Controller – Model | INT-TC25 |
| AI-11 | TiketSengketaUI / TiketSengketaController | TiketSengketa, RiwayatSengketa dan refund | Controller – Model | INT-TC26, INT-TC27, INT-TC28 |
| AI-12 | NotifikasiUI / NotifikasiController | Notifikasi | Controller – Model | INT-TC29 |
| AI-13 | Model-model Kerja-In | SQLite | Aplikasi – Basis data | INT-TC30, INT-TC31 |
| AI-14 | Profil publik dan katalog | Profil, lowongan tersimpan dan undangan | Controller – Model | INT-TC32 |

Tabel 4.3.2. Hasil Pengujian Integrasi

| ID Pengujian | ID Antarmuka | Skenario | Prosedur/Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| INT-TC01 | AI-01 | auth-flow | `tests/integration/auth-flow.test.ts` | fixture frontend sesuai kontrak respons autentikasi; mendaftarkan TK beserta profil dan cookie sesi | 19/19 kasus lulus | Pass |
| INT-TC02 | AI-01 | auth | `tests/integration/auth.test.ts` | hash Argon2id, verifikasi benar/salah, hash rusak = false; DB menyimpan SHA-256 token, bukan token mentah; cookie HttpOnly diset | 18/18 kasus lulus | Pass |
| INT-TC03 | AI-01 | reset-sandi | `tests/integration/reset-sandi.test.ts` | respons email terdaftar dan tidak terdaftar identik, token tidak bocor ke respons; token acak 32 byte hanya tersimpan sebagai SHA-256 dan berlaku 30 menit | 10/10 kasus lulus | Pass |
| INT-TC04 | AI-02 | verifikasi | `tests/integration/verifikasi.test.ts` | TK belum terverifikasi: 201, status menunggu, berkas tersimpan terenkripsi; GET /status mengembalikan status terkini | 7/7 kasus lulus | Pass |
| INT-TC05 | AI-02 | verifikasi-cs | `tests/integration/verifikasi-cs.test.ts` | CS melihat antrean MENUNGGU sesuai skema; non-CS -> 403, tanpa sesi -> 401 | 7/7 kasus lulus | Pass |
| INT-TC06 | AI-03 | lowongan | `tests/integration/lowongan.test.ts` | PK: 201, status OPEN, jumlahDiterima 0, sesuai skema, muncul di lowongan saya; field tidak valid -> 400 dengan daftar field | 13/13 kasus lulus | Pass |
| INT-TC07 | AI-03 | lowongan-fts | `tests/integration/lowongan-fts.test.ts` | toFtsQuery mengutip frasa dan menggandakan tanda kutip; hasil sama dengan LIKE untuk "atap" | 30/30 kasus lulus | Pass |
| INT-TC08 | AI-04 | penawaran | `tests/integration/penawaran.test.ts` | TK terverifikasi: 201, status MENUNGGU, sesuai skema, PK dapat notifikasi; penawaran kedua yang masih aktif -> 409 PENAWARAN_GANDA | 9/9 kasus lulus | Pass |
| INT-TC09 | AI-04 | pilih-pelamar | `tests/integration/pilih-pelamar.test.ts` | PK pemilik: daftar sesuai skema; yang ditarik tidak muncul; menunggu lebih dulu; tanpa sesi 401; TK 403; PK lain 403; id tak dikenal atau tak valid 404 | 9/9 kasus lulus | Pass |
| INT-TC10 | AI-04 | domain-lintas | `tests/integration/domain-lintas.test.ts` | dua proses menerima penawaran berbeda serentak: tepat satu sukses; tk2 (BELUM_TERVERIFIKASI) yang memegang transaksi IN_PROGRESS tidak bisa mengunggah bukti | 4/4 kasus lulus | Pass |
| INT-TC11 | AI-05 | transaksi | `tests/integration/transaksi.test.ts` | peserta dapat melihat daftar dan detail status Indonesia; peran bukan peserta ditolak 403 | 8/8 kasus lulus | Pass |
| INT-TC12 | AI-05 | transaksi-pemeriksaan | `tests/integration/transaksi-pemeriksaan.test.ts` | mengkredit upah tepat sekali, meskipun helper saldo dipanggil ulang; menolak persetujuan bila tagihan belum berhasil atau tiket masih aktif | 4/4 kasus lulus | Pass |
| INT-TC13 | AI-05 | transaksi-paginasi | `tests/integration/transaksi-paginasi.test.ts` | TK: semua transaksi dapat dijangkau tanpa duplikasi walaupun waktu dibuat sama; TK: filter berlaku pada items, total, dan setiap halaman | 13/13 kasus lulus | Pass |
| INT-TC14 | AI-06 | transaksi-bukti | `tests/integration/transaksi-bukti.test.ts` | TK terverifikasi yang ditugaskan dapat mengirim bukti; TK, PK, dan CS melihat bukti terbaru dan dapat membuka berkas; non-peserta ditolak | 10/10 kasus lulus | Pass |
| INT-TC15 | AI-06 | berkas | `tests/integration/berkas.test.ts` | peserta (TK dan PK) dan CS boleh mengunduh, tanpa cache; bukan peserta -> 403 (KNF06); tanpa sesi -> 401 | 5/5 kasus lulus | Pass |
| INT-TC16 | AI-07 | tagihan | `tests/integration/tagihan.test.ts` | POST /api/transaksi/:id/tagihan: berhasil membuat tagihan baru (201) dengan rumus komisi yang benar; POST /api/transaksi/:id/tagihan: jika tagihan aktif sudah ada, kembalikan tagihan yang sama (idempotent, 200); halaman pembayaran membuat dan menggunakan ulang satu tagihan, serta menolak transaksi tidak ditemukan (404) atau sedang berjalan (409) | 11/11 kasus lulus | Pass |
| INT-TC17 | AI-07 | tagihan-kedaluwarsa-ulang | `tests/integration/tagihan-kedaluwarsa-ulang.test.ts` | Cek kedaluwarsa lazy saat dibaca: status MENUNGGU_PEMBAYARAN yang expiry < now otomatis menjadi KEDALUWARSA; Cek kedaluwarsa lazy saat dibayar: tagihan yang expiry < now ditolak 409 dan statusnya menjadi KEDALUWARSA | 5/5 kasus lulus | Pass |
| INT-TC18 | AI-07 | pembayaran-saldo | `tests/integration/pembayaran-saldo.test.ts` | memanggil bayarTagihan / buatTagihan berulang kali tidak pernah menghasilkan dua tagihan aktif; Webhook signature salah → 401; dan data DB sama sekali tidak berubah | 7/7 kasus lulus | Pass |
| INT-TC19 | AI-08 | pembayaran-webhook | `tests/integration/pembayaran-webhook.test.ts` | POST /api/tagihan/:id/bayar: berhasil memproses bayar, mengubah status ke DIPROSES dan mengembalikan redirectUrl; POST /api/tagihan/:id/bayar: PK lain ditolak 403 FORBIDDEN | 8/8 kasus lulus | Pass |
| INT-TC20 | AI-08 | payment-security | `tests/integration/payment-security.test.ts` | tanpa sesi ditolak 401 tanpa mutasi; pemilik lain ditolak 403 tanpa mutasi | 21/21 kasus lulus | Pass |
| INT-TC21 | AI-09 | dompet | `tests/integration/dompet.test.ts` | GET /api/dompet tanpa autentikasi mengembalikan 401 UNAUTHENTICATED; GET /api/dompet dengan peran bukan TK (misal PK) mengembalikan 403 FORBIDDEN | 6/6 kasus lulus | Pass |
| INT-TC22 | AI-09 | pencairan | `tests/integration/pencairan.test.ts` | POST /api/pencairan tanpa autentikasi mengembalikan 401 UNAUTHENTICATED; POST /api/pencairan oleh peran PK mengembalikan 403 FORBIDDEN | 11/11 kasus lulus | Pass |
| INT-TC23 | AI-09 | pencairan-retry | `tests/integration/pencairan-retry.test.ts` | GAGAL definitif membebaskan reservasi tanpa debit; replay tidak mengirim lagi; exception tidak melepas reservasi; retry memakai ID, rekening, dan nominal yang sama | 18/18 kasus lulus | Pass |
| INT-TC24 | AI-09 | rekening | `tests/integration/rekening.test.ts` | pengajuan dan replay menyimpan ciphertext, log tanpa rekening lengkap, respons masked; migrasi rekening lama dan log append-only idempoten, menjaga identitas log dan saldo | 6/6 kasus lulus | Pass |
| INT-TC25 | AI-10 | profil | `tests/integration/profil.test.ts` | fixture frontend mengikuti skema respons; GET/PATCH tanpa sesi ditolak 401 | 11/11 kasus lulus | Pass |
| INT-TC26 | AI-11 | tiket-sengketa | `tests/integration/tiket-sengketa.test.ts` | bantuan umum tanpa transaksi: 201, nomor KIN-xxxxxx, riwayat awal, pekerjaan tidak berubah; dari transaksi: peserta PK/TK diterima, pekerjaan DISENGKETAKAN dan status asal disimpan; berkas ikut tersimpan | 17/17 kasus lulus | Pass |
| INT-TC27 | AI-11 | sengketa-putusan | `tests/integration/sengketa-putusan.test.ts` | pekerjaan COMPLETED, upah dikredit sekali, tiket DITUTUP, kedua pihak diberi notifikasi; keputusan berbeda pada tiket yang sudah diputus: 409 | 6/6 kasus lulus | Pass |
| INT-TC28 | AI-11 | refund | `tests/integration/refund.test.ts` | menolak tanpa sesi atau selain CS sebelum gateway; menolak ID tiket palsu atau transaksi tidak ada sebelum gateway | 16/16 kasus lulus | Pass |
| INT-TC29 | AI-12 | notifikasi | `tests/integration/notifikasi.test.ts` | fixture UI mengikuti kontrak respons; GET dan POST tanpa sesi menghasilkan 401 | 11/11 kasus lulus | Pass |
| INT-TC30 | AI-13 | db | `tests/integration/db.test.ts` | migrasi idempoten: menjalankan ulang tidak menerapkan apa pun; seed membuat 5 akun, ±30 lowongan, transaksi di tiap status, 1 tiket aktif | 8/8 kasus lulus | Pass |
| INT-TC31 | AI-13 | test-db | `tests/integration/test-db.test.ts` | setiap DB terisolasi, termigrasi/seed, dan dibersihkan secara idempoten; binding aplikasi memakai DB sementara dan mengembalikan environment/singleton setelah tutup | 3/3 kasus lulus | Pass |
| INT-TC32 | AI-14 | tersimpan-undangan | `tests/integration/tersimpan-undangan.test.ts` | simpan idempoten, muncul di daftar sesuai skema, hapus idempoten; lowongan tidak ada atau tidak OPEN -> 404; id tidak valid -> 404 | 10/10 kasus lulus | Pass |

## 4.4 Pengujian Use Case

Skenario mengikuti SKPL 4.4. Bukti diperoleh dari browser Edge dan permintaan HTTP pada aplikasi lokal.

### 4.4.1 Use Case Melakukan Registrasi

**ID Use Case:** UC01<br>
**Nama Use Case:** Melakukan Registrasi

Tabel 4.4.1. Hasil Pengujian Use Case UC01

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC01-TC01 | KF01, KF02, KF03 | Normal | 1. Pengguna memilih opsi registrasi<br>2. Pengguna mengisi formulir profil lengkap, memasukkan tanggal lahir (usia $\ge$ 17 tahun), dan menyetujui kebijakan privasi lalu menekan daftar<br>3. Pengguna melakukan login dengan kredensial yang baru dibuat | Akun TK baru, usia ≥17, setuju privasi, kredensial valid | Sistem menampilkan formulir registrasi, pilihan peran (Tenaga Kerja atau Penyedia Kerja), dan meminta persetujuan kebijakan privasi<br>Sistem memvalidasi usia pendaftar dan menyimpan data pengguna<br>Sistem memverifikasi kredensial, menerbitkan token autentikasi, dan menampilkan halaman beranda | Akun tersimpan, lalu login berhasil dan dashboard TK terbuka. | Pass |
| UC01-TC02 | KF01, KF02, KF03 | Alternatif 1: Batas Usia Tidak Valid | 1. Pengguna memilih opsi registrasi<br>2. Pengguna memasukkan tanggal lahir yang menunjukkan usia di bawah 17 tahun dan menekan daftar<br>3. Pengguna memperbaiki input tanggal lahir menjadi valid | Tanggal lahir 2015-01-01 | Sistem menampilkan formulir registrasi, pilihan peran, dan kebijakan privasi<br>Sistem memblokir pendaftaran dan menampilkan pesan kesalahan bahwa pengguna harus berusia minimal 17 tahun<br>Sistem kembali ke langkah 2 skenario normal | Usia di bawah 17 tahun ditolak; pesan batas usia muncul. | Pass |
| UC01-TC03 | KF01, KF02, KF03 | Alternatif 2: Email Sudah Terdaftar | 1. Pengguna memilih opsi registrasi<br>2. Pengguna mengisi formulir dengan email yang sudah ada di basis data dan menekan daftar<br>3. Pengguna memilih opsi menuju halaman login | Email akun seed | Sistem menampilkan formulir registrasi, pilihan peran, dan kebijakan privasi<br>Sistem menolak pendaftaran dan menampilkan pesan bahwa email sudah digunakan, serta menyarankan pengguna untuk login<br>Sistem mengarahkan pengguna ke halaman login | Email terdaftar ditolak; aplikasi menyarankan masuk. | Pass |

### 4.4.2 Use Case Mengelola Verifikasi Identitas

**ID Use Case:** UC02<br>
**Nama Use Case:** Mengelola Verifikasi Identitas

Tabel 4.4.2. Hasil Pengujian Use Case UC02

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC02-TC01 | KF04, KF05, KF06 | Normal | 1. Tenaga Kerja memilih menu verifikasi identitas<br>2. Tenaga Kerja mengunggah dokumen dan mengirimkan pengajuan<br>3. Customer Service menekan tombol setuju verifikasi manual pada dashboard | PDF uji, persetujuan, aksi setujui CS | Sistem menampilkan antarmuka pengunggahan dokumen identitas<br>Sistem menyimpan dokumen dan mengubah status menjadi "Menunggu Persetujuan"<br>Sistem memperbarui status identitas pengguna menjadi "Terverifikasi" dan membuka akses fitur utama platform | Unggahan diterima dan status akhir TERVERIFIKASI setelah persetujuan CS. | Pass |
| UC02-TC02 | KF04, KF05, KF06 | Alternatif 1: Format atau Ukuran Dokumen Tidak Valid | 1. Tenaga Kerja memilih menu verifikasi identitas<br>2. Tenaga Kerja mengunggah file dengan ekstensi yang tidak didukung (misal: .exe) atau melebihi batas ukuran (misal: > 5MB) | Berkas .exe | Sistem menampilkan antarmuka pengunggahan dokumen identitas<br>Sistem menolak unggahan dan menampilkan pesan error format/ukuran file tidak sesuai | Unggahan ditolak dengan HTTP 400. | Pass |
| UC02-TC03 | KF04, KF05, KF06 | Alternatif 2: Dokumen Ditolak oleh Customer Service | 1. Tenaga Kerja memilih menu verifikasi identitas<br>2. Tenaga Kerja mengunggah dokumen yang buram atau data tidak cocok<br>3. Customer Service menolak verifikasi pada dashboard dengan memberikan alasan | PDF uji dan alasan penolakan | Sistem menampilkan antarmuka pengunggahan dokumen identitas<br>Sistem menyimpan dokumen sebagai "Menunggu Persetujuan"<br>Sistem memperbarui status menjadi "Ditolak", mengirim notifikasi revisi beserta alasan, dan fitur utama tetap dibatasi | CS menolak dokumen; status DITOLAK tampil. | Pass |
| UC02-TC04 | KF04, KF05, KF06 | Alternatif 3: Mengakses Fitur Utama Sebelum Terverifikasi | 1. Tenaga Kerja (dengan status belum terverifikasi) mencoba menekan menu fitur utama platform<br>2. Sistem memblokir akses ke halaman tersebut | TK belum terverifikasi | Sistem mendeteksi status akun belum disetujui<br>Sistem menampilkan pop-up peringatan bahwa akun harus diverifikasi dan mengarahkan pengguna ke halaman verifikasi | Penawaran ditolak dengan HTTP 403. | Pass |

### 4.4.3 Use Case Mengelola Lowongan Pekerjaan

**ID Use Case:** UC03<br>
**Nama Use Case:** Mengelola Lowongan Pekerjaan

Tabel 4.4.3. Hasil Pengujian Use Case UC03

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC03-TC01 | KF07, KF08 | Normal | 1. Penyedia Kerja memilih opsi buat lowongan baru<br>2. Penyedia Kerja mengisi seluruh isian (judul, deskripsi, kuota, lokasi, upah) secara lengkap lalu menekan simpan | bantu shifu testing, kuota 1, upah Rp125.000 | Sistem menampilkan antarmuka formulir lowongan pekerjaan<br>Sistem memvalidasi isian, menyimpan lowongan, dan menetapkan status bawaan menjadi "Open" | Lowongan tersimpan dengan status OPEN. | Pass |
| UC03-TC02 | KF07, KF08 | Alternatif 1: Isian Formulir Kosong atau Tidak Valid | 1. Penyedia Kerja memilih opsi buat lowongan baru<br>2. Penyedia Kerja mengosongkan bagian upah atau kuota dan menekan simpan<br>3. Penyedia Kerja melengkapi isian yang kosong dengan data valid | Judul kosong, kuota 0, upah negatif | Sistem menampilkan antarmuka formulir lowongan pekerjaan<br>Sistem mendeteksi isian tidak valid, menggagalkan penyimpanan, dan menampilkan pesan peringatan atribut mana yang masih kosong<br>Sistem kembali ke langkah 2 skenario normal | HTTP 400; kolom judul, kuota, dan upah ditolak. | Pass |
| UC03-TC03 | KF07, KF08 | Alternatif 2: Membatalkan Pembuatan Lowongan | 1. Penyedia Kerja memilih opsi buat lowongan baru<br>2. Penyedia Kerja mengisi sebagian isian, lalu menekan tombol batal | Form tanpa penyimpanan | Sistem menampilkan antarmuka formulir lowongan pekerjaan<br>Sistem membuang isian yang belum disimpan dan mengarahkan pengguna kembali ke halaman beranda/daftar lowongan | Kembali ke daftar tanpa perubahan jumlah lowongan. | Pass |

### 4.4.4 Use Case Mencari Lowongan Pekerjaan

**ID Use Case:** UC04<br>
**Nama Use Case:** Mencari Lowongan Pekerjaan

Tabel 4.4.4. Hasil Pengujian Use Case UC04

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC04-TC01 | KF09 | Normal | 1. Tenaga Kerja membuka halaman pencarian pekerjaan atau memasukkan parameter filter seperti kategori/keterampilan<br>2. Tenaga Kerja menekan tombol cari/terapkan filter | bantu shifu testing | Sistem memproses kriteria pencarian dari pengguna<br>Sistem merender dan menampilkan daftar lowongan pekerjaan yang berstatus "Open" sesuai dengan kriteria yang diminta | Lowongan uji muncul pada hasil pencarian. | Pass |
| UC04-TC02 | KF09 | Alternatif 1: Pencarian Tidak Ditemukan | 1. Tenaga Kerja memasukkan kata kunci keterampilan yang sangat spesifik di kolom pencarian<br>2. Tenaga Kerja menekan tombol cari | Kata kunci unik tanpa kecocokan | Sistem memfilter lowongan berstatus "Open" dan tidak menemukan kecocokan data<br>Sistem menampilkan halaman kosong dengan pesan "Tidak ada lowongan yang sesuai dengan pencarian Anda" | Kata kunci uji tidak menghasilkan lowongan. | Pass |

### 4.4.5 Use Case Mengajukan Penawaran Pekerjaan

**ID Use Case:** UC05<br>
**Nama Use Case:** Mengajukan Penawaran Pekerjaan

Tabel 4.4.5. Hasil Pengujian Use Case UC05

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC05-TC01 | KF10, KF11 | Normal | 1. Tenaga Kerja dengan status akun Terverifikasi membuka halaman detail lowongan pekerjaan<br>2. Tenaga Kerja menekan tombol "Ajukan Penawaran"<br>3. Tenaga Kerja mengisi pesan penawaran dan menekan tombol konfirmasi pengajuan | TK terverifikasi dan upah Rp125.000 | Sistem memvalidasi status akun dan menampilkan tombol "Ajukan Penawaran" pada halaman tersebut<br>Sistem menampilkan antarmuka formulir pengajuan penawaran<br>Sistem menyimpan data pengajuan (ID Tenaga Kerja, ID Lowongan, pesan, dan timestamp) ke basis data, lalu menampilkan notifikasi keberhasilan | Konfirmasi menampilkan pesan penawaran sudah diajukan; penawaran tersimpan. | Pass |
| UC05-TC02 | KF10, KF11 | Alternatif 1: Akun Belum Terverifikasi | 1. Tenaga Kerja dengan status akun Belum Terverifikasi membuka halaman detail lowongan pekerjaan | TK belum terverifikasi | Sistem tidak menampilkan tombol "Ajukan Penawaran" atau menonaktifkannya dan memunculkan peringatan bahwa pengguna harus menyelesaikan verifikasi identitas terlebih dahulu | HTTP 403; tombol ajukan tidak muncul. | Pass |
| UC05-TC03 | KF10, KF11 | Alternatif 2: Pembatalan Pengajuan | 1. Tenaga Kerja menekan tombol "Ajukan Penawaran" pada detail pekerjaan<br>2. Tenaga Kerja berubah pikiran dan menekan tombol "Batal" atau "Kembali" | Tutup dialog dengan Escape | Sistem menampilkan antarmuka formulir pengajuan penawaran<br>Sistem menutup formulir pengajuan dan mengembalikan tampilan ke halaman detail pekerjaan tanpa menyimpan data apapun | Dialog ditutup dan jumlah penawaran tetap nol. | Pass |

### 4.4.6 Use Case Memilih Tenaga Kerja

**ID Use Case:** UC06<br>
**Nama Use Case:** Memilih Tenaga Kerja

Tabel 4.4.6. Hasil Pengujian Use Case UC06

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC06-TC01 | KF12, KF13 | Normal | 1. Penyedia Kerja membuka halaman lowongan miliknya dan memilih tab "Daftar Pelamar".<br>2. Penyedia Kerja meninjau profil pelamar dan menekan tombol "Pilih" pada salah satu kandidat yang cocok.<br>3. Penyedia Kerja mengonfirmasi persetujuan kandidat tersebut. | Satu pelamar, kuota 1 | Sistem memuat dan menampilkan daftar pelamar yang telah mengajukan penawaran beserta profil singkat, pesan penawaran, rating, dan portofolio pelamar.<br>Sistem menampilkan dialog konfirmasi persetujuan pelamar beserta rincian lowongan dan sisa kuota yang tersedia.<br>Sistem memvalidasi sisa kuota lowongan, membuat entri ID Transaksi Pekerjaan yang unik antara Penyedia Kerja dan Tenaga Kerja terpilih, serta mengubah status pelamar menjadi "Accepted".<br>Sistem memeriksa jumlah pelamar yang disetujui. Karena kuota telah terpenuhi, sistem secara otomatis mengubah status lowongan dari "Open" menjadi "Closed/Full" dan menampilkan pesan berhasil. | HTTP 200 mengembalikan ID transaksi; detail transaksi tampil. | Pass |
| UC06-TC02 | KF12, KF13 | Alternatif 1: Kuota Lowongan Sudah Penuh Saat Konfirmasi | 1. Penyedia Kerja membuka daftar pelamar dan menekan tombol "Pilih" pada kandidat.<br>2. Penyedia Kerja mengonfirmasi persetujuan kandidat. | Terima ulang setelah slot terisi | Sistem menampilkan dialog konfirmasi persetujuan.<br>Sistem mendeteksi bahwa kuota penerimaan untuk lowongan tersebut sudah penuh.<br>Sistem membatalkan aksi persetujuan, memperbarui status lowongan menjadi "Closed/Full", dan menampilkan pesan error bahwa kuota lowongan telah penuh. | Pengajuan ulang ditolak. Perlombaan dua pelamar pada kuota terakhir tercakup di uji integrasi. | Pass pada integrasi |
| UC06-TC03 | KF12, KF13 | Alternatif 2: Penyedia Kerja Membatalkan Pemilihan Pelamar | 1. Penyedia Kerja menekan tombol "Pilih" pada kandidat.<br>2. Penyedia Kerja menekan tombol "Batal". | Keluar tanpa memilih | Sistem menampilkan dialog konfirmasi persetujuan kandidat.<br>Sistem menutup dialog konfirmasi dan mempertahankan status daftar pelamar tanpa ada perubahan data. | Tidak ada transaksi saat keluar dari daftar pelamar tanpa memilih. | Pass |

### 4.4.7 Use Case Melakukan Pembayaran Pekerjaan

**ID Use Case:** UC07<br>
**Nama Use Case:** Melakukan Pembayaran Pekerjaan

Tabel 4.4.7. Hasil Pengujian Use Case UC07

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC07-TC01 | KF14, KF15 | Normal | 1. Penyedia Kerja membuka rincian transaksi pekerjaan yang telah disepakati dan menekan tombol "Bayar".<br>2. Penyedia Kerja memilih metode pembayaran dan menekan "Lanjutkan Pembayaran".<br>3. Penyedia Kerja menyelesaikan pembayaran melalui metode pembayaran yang dipilih. | QRIS, callback BERHASIL | Sistem menghitung total rincian tagihan (upah tenaga kerja + *commission fee* platform) dan menampilkan rincian pembayaran beserta tombol instruksi pembayaran.<br>Sistem menghubungi API Payment Gateway dummy, menerbitkan ID tagihan/pembayaran, dan menampilkan kode pembayaran / tautan transaksi.<br>Sistem menerima notifikasi konfirmasi pembayaran berhasil dari Payment Gateway dummy.<br>Sistem memverifikasi pembayaran, mencatat riwayat transaksi, mengubah status pekerjaan dari "Assigned" menjadi "In Progress", serta mengirimkan notifikasi kepada Tenaga Kerja bahwa pekerjaan siap dimulai. | Simulasi berhasil; transaksi menjadi IN_PROGRESS. | Pass pada simulator |
| UC07-TC02 | KF14, KF15 | Alternatif 1: Pembayaran Gagal atau Dibatalkan oleh Payment Gateway dummy | 1. Penyedia Kerja memilih metode pembayaran dan menekan "Lanjutkan Pembayaran".<br>2. Pembayaran gagal diproses oleh saluran pembayaran (misal: saldo tidak mencukupi atau transaksi ditolak).<br>3. Penyedia Kerja memilih opsi metode pembayaran lain. | Callback GAGAL | Sistem mengarahkan Penyedia Kerja ke halaman transaksi Payment Gateway dummy.<br>Sistem menerima notifikasi kegagalan transaksi dari Payment Gateway dummy, mencatat status transaksi sebagai "Failed", dan menampilkan pesan kesalahan kepada Penyedia Kerja beserta opsi untuk mencoba metode pembayaran lain.<br>Sistem kembali ke langkah 2 skenario normal untuk membuat instruksi pembayaran baru. | Callback gagal; pekerjaan tidak berubah ke IN_PROGRESS. | Pass |
| UC07-TC03 | KF14, KF15 | Alternatif 2: Waktu Pembayaran Habis (Timeout / Expired) | 1. Penyedia Kerja mendapatkan kode pembayaran dengan batas waktu tertentu.<br>2. Penyedia Kerja tidak melakukan pembayaran hingga batas waktu terlewati. | Callback KEDALUWARSA | Sistem mencatat batas waktu pembayaran (*expiry timestamp*) dan menunggu konfirmasi pembayaran.<br>Sistem menerima notifikasi kedaluwarsa dari Payment Gateway dummy, mencatat status pembayaran "Expired", dan mengembalikan status transaksi ke antrean tagihan yang belum dibayar. | Callback kedaluwarsa diterima; status tagihan kedaluwarsa tercatat. | Pass |

### 4.4.8 Use Case Menyerahkan Hasil Pekerjaan

**ID Use Case:** UC08<br>
**Nama Use Case:** Menyerahkan Hasil Pekerjaan

Tabel 4.4.8. Hasil Pengujian Use Case UC08

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC08-TC01 | KF16 | Normal | 1. Tenaga Kerja membuka halaman detail pekerjaan aktif  yang berstatus "In Progress" dan menekan tombol "Serahkan Hasil Pekerjaan".<br>2. Tenaga Kerja mengisi deskripsi pengerjaan, mengunggah berkas bukti (foto/dokumen dengan limit ukuran file), dan menekan tombol "Kirim Hasil Pekerjaan".<br>3. Tenaga Kerja mengonfirmasi penyerahan pada bukti konfirmasi akhir. | PDF uji dan deskripsi | Sistem menampilkan formulir penyerahan pekerjaan yang berisi catatan penyelesaian dan kolom pengunggahan berkas bukti/lampiran.<br>Sistem memvalidasi kelengkapan isian serta format dan ukuran berkas yang diunggah.<br>Sistem menyimpan berkas lampiran, mencatat stempel waktu pengiriman (*timestamp*), mengubah status pekerjaan menjadi "Submitted", serta mengirimkan notifikasi peninjauan hasil kepada Penyedia Kerja. | HTTP 201; bukti tampil dan transaksi menjadi SUBMITTED. | Pass |
| UC08-TC02 | KF16 | Alternatif 1: Ukuran Berkas Melebihi Batas Maksimal | 1. Tenaga Kerja memilih berkas bukti yang berukuran lebih besar dari batas ketentuan (misal > 10 MB).<br>2. Tenaga Kerja memilih berkas baru yang sesuai dengan batasan ukuran. | Berkas 10 MiB + 1 byte | Sistem mendeteksi ukuran berkas melebihi kuota penyimpanan yang diizinkan.<br>Sistem menggagalkan pengunggahan berkas, menampilkan pesan peringatan "Ukuran berkas melebihi batas maksimal 10 MB", dan meminta Tenaga Kerja memilih berkas lain.<br>Sistem memvalidasi berkas baru dan kembali ke langkah 2 skenario normal. | Unggahan melebihi 10 MiB ditolak. | Pass |
| UC08-TC03 | KF16 | Alternatif 2: Tenaga Kerja Belum Mengunggah Berkas Wajib | 1. Tenaga Kerja mengosongkan kolom lampiran bukti dan langsung menekan tombol "Kirim Hasil Pekerjaan". | Deskripsi tanpa berkas | Sistem mendeteksi bahwa bukti pengerjaan wajib dilampirkan.<br>Sistem menampilkan pesan peringatan bahwa bukti pekerjaan tidak boleh kosong dan menolak pengiriman formulir hingga berkas diunggah. | Permintaan tanpa berkas ditolak. | Pass |

### 4.4.9 Use Case Memverifikasi Penyelesaian Pekerjaan

**ID Use Case:** UC09<br>
**Nama Use Case:** Memverifikasi Penyelesaian Pekerjaan

Tabel 4.4.9. Hasil Pengujian Use Case UC09

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC09-TC01 | KF17, KF18 | Normal | 1. Penyedia Kerja membuka halaman rincian pekerjaan yang berstatus "Submitted".<br>2. Penyedia Kerja memeriksa hasil kerja dan menekan tombol "Konfirmasi Selesai".<br>3. Penyedia Kerja mengonfirmasi persetujuan hasil kerja. | Bukti revisi dan persetujuan PK | Sistem menampilkan deskripsi hasil pekerjaan beserta lampiran bukti pengerjaan yang telah diunggah Tenaga Kerja.<br>Sistem menampilkan bukti konfirmasi penyelesaian pekerjaan dengan peringatan bahwa dana upah akan langsung diteruskan ke Tenaga Kerja.<br>Sistem mengubah status pekerjaan menjadi "Completed", memicu instruksi penyaluran upah ke akun Tenaga Kerja, memperbarui saldo pendapatan Tenaga Kerja, dan mengirimkan notifikasi penerimaan upah.<br>Sistem secara otomatis mengarahkan Penyedia Kerja ke antarmuka formulir rating dan ulasan (UC10). | Status COMPLETED dan saldo bertambah Rp125.000. Pencairan ke rekening harus diajukan terpisah. | Fail (KF17: pencairan rekening tidak otomatis; selaraskan alur atau SKPL) |
| UC09-TC02 | KF17, KF18 | Alternatif 1: Hasil Pekerjaan Belum Sesuai (Penyedia Kerja Meminta Revisi) | 1. Penyedia Kerja memeriksa hasil kerja dan mendapati hasil pekerjaan belum sesuai kesepakatan.<br>2. Penyedia Kerja mengisi catatan kekurangan pekerjaan pada kolom deskripsi revisi dan menekan "Kirim Permintaan Revisi". | Catatan revisi | Penyedia Kerja menekan tombol "Minta Revisi / Perbaikan".<br>Sistem menyimpan catatan revisi, mengembalikan status pekerjaan menjadi "In Progress", serta mengirimkan notifikasi permintaan revisi kepada Tenaga Kerja. | Permintaan revisi diterima dan dicatat. | Pass |
| UC09-TC03 | KF17, KF18 | Alternatif 2: Terjadi Ketidaksepakatan / Perselisihan Hasil Kerja | 1. Penyedia Kerja memeriksa hasil pekerjaan namun Tenaga Kerja tidak menyelesaikan tanggung jawab sama sekali atau melanggar kesepakatan. | Kategori hasil pekerjaan dan uraian sengketa | Penyedia Kerja menekan tombol "Ajukan Komplain".<br>Sistem mengarahkan Penyedia Kerja ke alur penanganan sengketa (UC11 / Menangani Keluhan dan Sengketa) serta menahan status dana pekerjaan. | Tiket terbit dan pekerjaan masuk peninjauan. | Pass |

### 4.4.10 Use Case Melakukan Pencairan Dana

**ID Use Case:** UC10<br>
**Nama Use Case:** Melakukan Pencairan Dana

Tabel 4.4.10. Hasil Pengujian Use Case UC10

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC10-TC01 | KF19, KF20 | Normal | 1. Tenaga Kerja membuka halaman saldo/dompet dan menekan tombol "Tarik Dana".<br>2. Tenaga Kerja memilih rekening tujuan, memasukkan nominal penarikan, dan menekan "Ajukan Pencairan".<br>3. Tenaga Kerja mengonfirmasi pengajuan pencairan. | Rekening uji dan Rp10.000 | Sistem menampilkan formulir pencairan dana beserta saldo yang tersedia dan kolom pilihan rekening bank/e-wallet tujuan.<br>Sistem memvalidasi data rekening tujuan dan nominal penarikan terhadap saldo yang tersedia.<br>Sistem mengubah status pencairan menjadi "Diproses".<br>Sistem menerima konfirmasi transfer berhasil dari Payment Gateway dummy, mencatat log pencairan (ID transaksi, nominal, identitas penerima, waktu, status transfer), mengurangi saldo, dan menampilkan notifikasi bahwa pencairan berhasil. | Permintaan Rp10.000 diterima; callback simulator berhasil; riwayat ada di dompet. | Pass pada simulator |
| UC10-TC02 | KF19, KF20 | Alternatif 1: Data Rekening/E-wallet Tidak Valid | 1. Tenaga Kerja memasukkan nomor rekening/e-wallet dengan format tidak valid dan menekan "Ajukan Pencairan". | Format rekening tidak valid | Sistem gagal memvalidasi data rekening tujuan.<br>Sistem menampilkan pesan kesalahan bahwa data rekening tidak valid dan meminta Tenaga Kerja memeriksa kembali data tujuan. | Rekening tidak valid ditolak dengan HTTP 400. | Pass |
| UC10-TC03 | KF19, KF20 | Alternatif 2: Nominal Penarikan Melebihi Saldo | 1. Tenaga Kerja memasukkan nominal penarikan yang lebih besar dari saldo yang tersedia. | Rp999.999.999 | Sistem mendeteksi nominal melebihi saldo tersedia.<br>Sistem menolak pengajuan, menampilkan pesan peringatan saldo tidak mencukupi, dan menggagalkan pengiriman instruksi ke Payment Gateway dummy. | Nominal di atas saldo ditolak. | Pass |

### 4.4.11 Use Case Memberikan Penilaian Kerja

**ID Use Case:** UC11<br>
**Nama Use Case:** Memberikan Penilaian Kerja

Tabel 4.4.11. Hasil Pengujian Use Case UC11

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC11-TC01 | KF21, KF22, KF23 | Normal | 1. Pengguna membuka halaman pekerjaan berstatus "Completed" dan menekan "Beri Rating & Ulasan".<br>2. Pengguna memilih nilai rating, mengisi ulasan, dan menekan "Kirim Ulasan". | Bintang 5 dan ulasan | Sistem menampilkan formulir rating (skala 1–5) dan kolom ulasan teks.<br>Sistem memvalidasi kelengkapan isian dan menyimpan data rating serta ulasan ke basis data.<br>Sistem mengunci formulir ulasan untuk pekerjaan tersebut, menghitung ulang rata-rata rating pengguna yang dinilai, dan memperbarui tampilan portofolio pada profilnya. | Ulasan bintang 5 diterima dan profil penerima ditampilkan. | Pass |
| UC11-TC02 | KF21, KF22, KF23 | Alternatif 1: Pengiriman Ulasan Ganda | 1. Pengguna yang sudah pernah mengirim ulasan mencoba membuka kembali formulir ulasan untuk pekerjaan yang sama. | Ulasan kedua dari akun yang sama | Sistem mendeteksi bahwa ulasan untuk pekerjaan tersebut sudah pernah dikirim.<br>Sistem mengunci formulir, menampilkan pesan bahwa ulasan sudah pernah diberikan, dan menolak pengiriman ulasan tambahan. | Pengiriman ulang ditolak dengan HTTP 409. | Pass |
| UC11-TC03 | KF21, KF22, KF23 | Alternatif 2: Rating Tidak Diisi | 1. Pengguna mengosongkan kolom rating dan langsung menekan "Kirim Ulasan". | Tidak mengisi rating | Sistem mendeteksi rating wajib belum dipilih.<br>Sistem menampilkan pesan peringatan bahwa rating wajib diisi dan menggagalkan pengiriman formulir. | Rating kosong ditolak dengan HTTP 400. | Pass |

### 4.4.12 Use Case Menangani Keluhan

**ID Use Case:** UC12<br>
**Nama Use Case:** Menangani Keluhan

Tabel 4.4.12. Hasil Pengujian Use Case UC12

| ID Pengujian | ID KF | Skenario | Prosedur Pengujian | Masukan | Hasil yang Diharapkan | Hasil Pengujian | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| UC12-TC01 | KF24, KF25, KF26 | Normal | 1. Pengguna membuka halaman pekerjaan bermasalah dan menekan "Ajukan Komplain/Keluhan".<br>2. Pengguna mengisi deskripsi keluhan, mengunggah bukti pendukung, dan menekan "Kirim Laporan".<br>3. Customer Service meninjau tiket, memeriksa bukti dari kedua pihak, dan menetapkan keputusan sengketa. | Tiket transaksi dan keputusan PENCAIRAN | Sistem menampilkan formulir laporan berisi kategori masalah, deskripsi, dan kolom unggah bukti pendukung.<br>Sistem menerbitkan tiket sengketa baru, menyimpan bukti yang diunggah, dan menampilkannya pada dashboard Customer Service.<br>Sistem mengeksekusi tindakan sesuai keputusan (refund ke Penyedia Kerja / pencairan dana ke Tenaga Kerja) dan mencatat perubahan status penanganan.<br>Sistem mencatat riwayat aktivitas penanganan sengketa secara kronologis dan mengirimkan notifikasi hasil keputusan kepada kedua pihak terkait. | CS menetapkan PENCAIRAN dan tiket ditutup. Keputusan menambah saldo internal. | Pass untuk alur internal |
| UC12-TC02 | KF24, KF25, KF26 | Alternatif 1: Permintaan Bukti Tambahan | 1. Customer Service menilai bukti yang diberikan belum cukup dan menekan "Minta Bukti Tambahan".<br>2. Pengguna mengunggah bukti tambahan yang diminta. | Pesan permintaan bukti | Sistem mengirimkan notifikasi permintaan bukti tambahan kepada pihak terkait dan mencatatnya dalam riwayat penanganan.<br>Sistem menyimpan bukti baru dan kembali ke langkah 3 skenario normal. | Permintaan bukti tambahan diterima dan tercatat. | Pass |
| UC12-TC03 | KF24, KF25, KF26 | Alternatif 2: Keluhan Ditolak karena Bukti Tidak Cukup | 1. Customer Service menetapkan bahwa laporan tidak memiliki dasar/bukti yang valid. | Alasan penolakan CS | Sistem mengubah status tiket menjadi "Ditolak".<br>Sistem mencatat alasan penolakan dalam riwayat penanganan dan mengirimkan notifikasi penolakan kepada pelapor tanpa mengeksekusi refund/pencairan. | Tiket ditolak setelah diperiksa; alasan penolakan tercatat. | Pass |
| UC12-TC04 | KF24, KF25, KF26 | Alternatif 3: Pengguna Membatalkan Tiket Keluhan | 1. Pelapor membuka tiket sengketa berstatus "Menunggu Peninjauan" dan menekan "Batalkan Laporan".<br>2. Pelapor mengonfirmasi pembatalan. | Tiket umum berstatus DIAJUKAN | Sistem menampilkan konfirmasi pembatalan tiket.<br>Sistem mengubah status tiket menjadi "Dibatalkan", mencatat pembatalan dalam riwayat penanganan, dan melepas penahanan dana pekerjaan (jika ada). | Tiket yang diajukan dibatalkan dan riwayat tampil. | Pass |

## 4.5 Pengujian Kebutuhan Non-Fungsional (KNF)

Tabel 4.5. Hasil Pengujian KNF

| ID Pengujian | ID KNF | Parameter | Target Terukur | Metode dan Alat | Hasil Aktual | Kesimpulan |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| KNF01-TC01 | KNF01 | Security | Kata sandi berupa hash dan token sesi tidak tersimpan sebagai teks biasa | Vitest, pemeriksaan SQLite | Hash Argon2id; token mentah tidak ditemukan pada penyimpanan sesi. | Pass |
| KNF02-TC01 | KNF02 | Security | Dokumen identitas tersimpan terenkripsi | Vitest, baca berkas penyimpanan uji | Unggahan diterima dan berkas tersimpan terenkripsi. | Pass |
| KNF03-TC01 | KNF03 | Response time | Pemeriksaan status akses < 1.000 ms | Playwright HTTP, 5 permintaan status setelah pemanasan | 5 pengukuran: rata-rata 31.03 ms, maksimum 37.05 ms. | Pass |
| KNF04-TC01 | KNF04 | Response Time | Hasil pencarian dirender ≤ 5.000 ms | Playwright Edge, 5 pemuatan sampai jaringan tenang | 5 pengukuran: rata-rata 1466.40 ms, maksimum 2022.00 ms. | Pass |
| KNF05-TC01 | KNF05 | Ergonomy | Tombol ajukan dan input formulir dapat dipakai pada viewport ponsel | Playwright, Edge Windows, emulasi sentuh 390 × 844 | Tombol Ajukan Penawaran membuka dialog, isian upah dan ketersediaan dapat diisi, dan layar tinjau terbuka. Lebar halaman tetap 390 px. | Pass pada viewport yang diuji |
| KNF06-TC01 | KNF06 | Security | Aksi persetujuan oleh selain pemilik ditolak | Vitest, pemilik dan pengguna lain pada SQLite uji | Aksi oleh penyedia lain diblokir. | Pass |
| KNF07-TC01 | KNF07 | Reliability | Tepat 1 transaksi dari 2 persetujuan serentak pada slot terakhir | Vitest, 2 proses dengan SQLite yang sama | Tepat 1 penerimaan sukses. | Pass |
| KNF08-TC01 | KNF08 | Memory | RAM browser ≤ 150 MB untuk daftar lowongan dan pelamar berukuran besar | Chrome DevTools Protocol, Runtime.getHeapUsage | Heap JavaScript tercatat 155,77 MB pada halaman pencarian. | Pengukuran parsial. Ukur RAM total pada kedua daftar dengan data berukuran besar. |
| KNF09-TC01 | KNF09 | Safety | Lowongan kelistrikan tidak tersimpan tanpa persetujuan risiko | Playwright pada Edge dan Chrome serta uji integrasi Vitest | Checkbox risiko tampil. Tanpa centang, wizard berhenti di langkah upah dan API menolak dengan HTTP 400. Setelah dicentang, wizard membuka halaman tinjau. | Pass |
| KNF10-TC01 | KNF10 | Availability | Gangguan akses basis data ≤ 24 jam dalam satu bulan | Pemantauan endpoint daftar lowongan selama satu bulan | Belum tersedia riwayat pemantauan satu bulan. | Belum diuji. Jalankan pemantauan berkala selama satu bulan. |
| KNF11-TC01 | KNF11 | Reliability | Pembayaran/konfirmasi berulang tidak menghasilkan tagihan atau mutasi ganda | Vitest, pengulangan pembayaran dan callback | Tidak terbentuk dua tagihan aktif pada pengulangan; callback diproses sekali. | Pass pada simulator |
| KNF12-TC01 | KNF12 | Security | Pengiriman data ke Payment Gateway melalui koneksi terenkripsi | Pemeriksaan konfigurasi uji lokal | Aplikasi memakai Payment Gateway dummy pada localhost. | Di luar lingkup simulasi lokal. |
| KNF13-TC01 | KNF13 | Response Time | Waktu respons unggah bukti | Playwright HTTP, 1 unggahan PDF uji dan pembacaan ulang | Respons unggah 129.24 ms; status SUBMITTED. | Terukur. SKPL belum menetapkan batas waktu lulus. |
| KNF14-TC01 | KNF14 | Security | Hanya TK yang ditugaskan dapat mengirim bukti | Vitest, TK yang ditugaskan dan akun lain | TK yang ditugaskan dapat mengirim; akun yang tidak berhak ditolak. | Pass |
| KNF15-TC01 | KNF15 | Reliability | Tidak ada kredit upah sebelum persetujuan atau keputusan sengketa | Vitest, inspeksi saldo dan mutasi transaksi | Kredit hanya terjadi setelah tindakan sah; kredit ulang tidak menggandakan mutasi. | Pass |
| KNF16-TC01 | KNF16 | Reliability | Tidak ada pencairan ganda ketika gateway timeout dan dilakukan pengulangan | Vitest, fixture kegagalan jaringan dan idempotensi | Retry memakai referensi yang sama; reservasi dan debit diperiksa pada SQLite uji. | Pass pada fixture |
| KNF17-TC01 | KNF17 | Security | Data rekening tersimpan terenkripsi dan koneksi gateway memakai TLS 1.3 | Vitest untuk penyimpanan rekening dan pemeriksaan konfigurasi gateway | Rekening tersimpan sebagai ciphertext. Gateway dummy berjalan di localhost. | Enkripsi rekening: Pass. TLS eksternal di luar lingkup simulasi lokal. |
| KNF18-TC01 | KNF18 | Response time | Waktu pembaruan agregat rating setelah ulasan dikirim | Playwright HTTP, 1 pengiriman ulasan | Respons pengiriman ulasan 440.97 ms. Waktu render rating pada profil belum diukur. | Pengukuran parsial. Tetapkan batas lulus dan ukur sampai rating tampil. |
| KNF19-TC01 | KNF19 | Security | Akun non-CS atau tanpa sesi tidak dapat mengelola sengketa | Vitest, peran CS, pengguna biasa, dan tanpa sesi | Pengguna non-CS menerima HTTP 403 dan tanpa sesi menerima HTTP 401. | Pass |
| KNF20-TC01 | KNF20 | Reliability | UPDATE/DELETE riwayat sengketa dan mutasi pencairan ditolak | Vitest, operasi terhadap data SQLite uji | UPDATE/DELETE pada riwayat sengketa ditolak; aturan ledger tercakup pada suite basis data. | Pass pada SQLite uji |
| KNF21-TC01 | KNF21 | Portability | Registrasi, pembuatan lowongan, dan penawaran adaptif lintas perangkat/OS | Playwright pada Windows: Edge 390 × 844 dengan emulasi sentuh dan Chrome 1440 × 900 | Form registrasi, empat langkah wizard lowongan, serta form dan tinjauan penawaran dapat digunakan tanpa gulir horizontal. Lebar aktual 390 px dan 1440 px pada kedua profil. | Pass pada kedua profil Windows yang diuji. Sistem operasi lain belum diuji. |
| KNF22-TC01 | KNF22 | Memory | Dokumen dan bukti dikompresi otomatis hingga ≤ 10 MB | Inspeksi alur unggah dan uji penolakan bukti > 10 MiB | Gambar bukti pekerjaan dikompresi. Unggahan bukti yang melebihi batas ditolak. | Belum terpenuhi untuk semua jenis berkas. Uji kompresi per format atau sesuaikan batasan di SKPL. |
| KNF23-TC01 | KNF23 | Availability | Uptime akses status verifikasi ≥ 99,9% | Pemantauan endpoint status verifikasi | Belum tersedia data uptime yang representatif. | Belum diuji. Catat permintaan berhasil dan gagal secara berkala di lingkungan yang digunakan. |

## 4.6 Tangkapan Layar dan Bukti Hasil Pengujian

Tabel 4.6. Bukti Hasil Pengujian

| ID Pengujian | Bukti Hasil Pengujian |
| :--- | :--- |
| INT-TC01 | [Vitest · auth-flow](./assets/layar/integration-auth-flow.png) |
| INT-TC02 | [Vitest · auth](./assets/layar/integration-auth.png) |
| INT-TC03 | [Vitest · reset-sandi](./assets/layar/integration-reset-sandi.png) |
| INT-TC04 | [Vitest · verifikasi](./assets/layar/integration-verifikasi.png) |
| INT-TC05 | [Vitest · verifikasi-cs](./assets/layar/integration-verifikasi-cs.png) |
| INT-TC06 | [Vitest · lowongan](./assets/layar/integration-lowongan.png) |
| INT-TC07 | [Vitest · lowongan-fts](./assets/layar/integration-lowongan-fts.png) |
| INT-TC08 | [Vitest · penawaran](./assets/layar/integration-penawaran.png) |
| INT-TC09 | [Vitest · pilih-pelamar](./assets/layar/integration-pilih-pelamar.png) |
| INT-TC10 | [Vitest · domain-lintas](./assets/layar/integration-domain-lintas.png) |
| INT-TC11 | [Vitest · transaksi](./assets/layar/integration-transaksi.png) |
| INT-TC12 | [Vitest · transaksi-pemeriksaan](./assets/layar/integration-transaksi-pemeriksaan.png) |
| INT-TC13 | [Vitest · transaksi-paginasi](./assets/layar/integration-transaksi-paginasi.png) |
| INT-TC14 | [Vitest · transaksi-bukti](./assets/layar/integration-transaksi-bukti.png) |
| INT-TC15 | [Vitest · berkas](./assets/layar/integration-berkas.png) |
| INT-TC16 | [Vitest · tagihan](./assets/layar/integration-tagihan.png) |
| INT-TC17 | [Vitest · tagihan-kedaluwarsa-ulang](./assets/layar/integration-tagihan-kedaluwarsa-ulang.png) |
| INT-TC18 | [Vitest · pembayaran-saldo](./assets/layar/integration-pembayaran-saldo.png) |
| INT-TC19 | [Vitest · pembayaran-webhook](./assets/layar/integration-pembayaran-webhook.png) |
| INT-TC20 | [Vitest · payment-security](./assets/layar/integration-payment-security.png) |
| INT-TC21 | [Vitest · dompet](./assets/layar/integration-dompet.png) |
| INT-TC22 | [Vitest · pencairan](./assets/layar/integration-pencairan.png) |
| INT-TC23 | [Vitest · pencairan-retry](./assets/layar/integration-pencairan-retry.png) |
| INT-TC24 | [Vitest · rekening](./assets/layar/integration-rekening.png) |
| INT-TC25 | [Vitest · profil](./assets/layar/integration-profil.png) |
| INT-TC26 | [Vitest · tiket-sengketa](./assets/layar/integration-tiket-sengketa.png) |
| INT-TC27 | [Vitest · sengketa-putusan](./assets/layar/integration-sengketa-putusan.png) |
| INT-TC28 | [Vitest · refund](./assets/layar/integration-refund.png) |
| INT-TC29 | [Vitest · notifikasi](./assets/layar/integration-notifikasi.png) |
| INT-TC30 | [Vitest · db](./assets/layar/integration-db.png) |
| INT-TC31 | [Vitest · test-db](./assets/layar/integration-test-db.png) |
| INT-TC32 | [Vitest · tersimpan-undangan](./assets/layar/integration-tersimpan-undangan.png) |
| C01-UT01, C01-UT02, C01-UT03, C01-UT04, C01-UT05, C01-UT06, C01-UT07, C01-UT08, C01-UT09, C01-UT10, C01-UT11, C01-UT12, C01-UT13, C01-UT14, C01-UT15, C01-UT16, C01-UT17, C01-UT18, C01-UT19, C01-UT20, C01-UT21, C01-UT22, C01-UT23, C01-UT24 | [Vitest · usia](./assets/layar/unit-usia.png)<br>[![C01-unit](./assets/layar/C01-unit.png)](./assets/layar/C01-unit.png) |
| C01 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png)<br>[Cakupan V8 · Utilitas](./assets/layar/coverage-lib.png) |
| C02 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C05 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C06 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10 | [Vitest · statusMachine](./assets/layar/unit-statusMachine.png)<br>[![C07-unit](./assets/layar/C07-unit.png)](./assets/layar/C07-unit.png) |
| C07 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C08-UT01, C08-UT02, C08-UT03, C08-UT04, C08-UT05, C08-UT06, C08-UT07, C08-UT08, C08-UT09 | [Vitest · storage](./assets/layar/unit-storage.png)<br>[![C08-unit](./assets/layar/C08-unit.png)](./assets/layar/C08-unit.png) |
| C08 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png)<br>[Cakupan V8 · Utilitas](./assets/layar/coverage-lib.png) |
| C09 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C10 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C12 (coverage) | [Cakupan V8 · Model](./assets/layar/coverage-models.png)<br>[Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13 | [Vitest · paymentAdapter](./assets/layar/unit-paymentAdapter.png) |
| C15 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png)<br>[Cakupan V8 · Utilitas](./assets/layar/coverage-lib.png) |
| C31 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C32 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C34 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C35 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C36 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C37 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C38 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C39 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C40-UT01, C40-UT02, C40-UT03 | [Vitest · rekening](./assets/layar/unit-rekening.png)<br>[![C40-unit](./assets/layar/C40-unit.png)](./assets/layar/C40-unit.png) |
| C40 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png)<br>[Cakupan V8 · Utilitas](./assets/layar/coverage-lib.png) |
| C41 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C42 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| C45 (coverage) | [Cakupan V8 · Controller](./assets/layar/coverage-controllers.png) |
| UC01-TC01 | [![UC01-TC01](./assets/layar/UC01-TC01.png)](./assets/layar/UC01-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC01-TC02 | [![UC01-TC02](./assets/layar/UC01-TC02.png)](./assets/layar/UC01-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC01-TC03 | [![UC01-TC03](./assets/layar/UC01-TC03.png)](./assets/layar/UC01-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC02-TC01 | [![UC02-TC01](./assets/layar/UC02-TC01.png)](./assets/layar/UC02-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC02-TC02 | [![UC02-TC02](./assets/layar/UC02-TC02.png)](./assets/layar/UC02-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC02-TC03 | [![UC02-TC03](./assets/layar/UC02-TC03.png)](./assets/layar/UC02-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC02-TC04 | [![UC02-TC04](./assets/layar/UC02-TC04.png)](./assets/layar/UC02-TC04.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC03-TC01 | [![UC03-TC01](./assets/layar/UC03-TC01.png)](./assets/layar/UC03-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC03-TC02 | [![UC03-TC02](./assets/layar/UC03-TC02.png)](./assets/layar/UC03-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC03-TC03 | [![UC03-TC03](./assets/layar/UC03-TC03.png)](./assets/layar/UC03-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC04-TC01 | [![UC04-TC01](./assets/layar/UC04-TC01.png)](./assets/layar/UC04-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC04-TC02 | [![UC04-TC02](./assets/layar/UC04-TC02.png)](./assets/layar/UC04-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-1.png) |
| UC05-TC01 | [![UC05-TC01](./assets/layar/UC05-TC01.png)](./assets/layar/UC05-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC05-TC02 | [![UC05-TC02](./assets/layar/UC05-TC02.png)](./assets/layar/UC05-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC05-TC03 | [![UC05-TC03](./assets/layar/UC05-TC03.png)](./assets/layar/UC05-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC06-TC01 | [![UC06-TC01](./assets/layar/UC06-TC01.png)](./assets/layar/UC06-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC06-TC02 | [![UC06-TC02](./assets/layar/UC06-TC02.png)](./assets/layar/UC06-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png)<br>[Vitest · domain-lintas](./assets/layar/integration-domain-lintas.png) |
| UC06-TC03 | [![UC06-TC03](./assets/layar/UC06-TC03.png)](./assets/layar/UC06-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC07-TC01 | [![UC07-TC01](./assets/layar/UC07-TC01.png)](./assets/layar/UC07-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC07-TC02 | [![UC07-TC02](./assets/layar/UC07-TC02.png)](./assets/layar/UC07-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC07-TC03 | [![UC07-TC03](./assets/layar/UC07-TC03.png)](./assets/layar/UC07-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC08-TC01 | [![UC08-TC01](./assets/layar/UC08-TC01.png)](./assets/layar/UC08-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC08-TC02 | [![UC08-TC02](./assets/layar/UC08-TC02.png)](./assets/layar/UC08-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC08-TC03 | [![UC08-TC03](./assets/layar/UC08-TC03.png)](./assets/layar/UC08-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-5.png) |
| UC09-TC01 | [![UC09-TC01](./assets/layar/UC09-TC01.png)](./assets/layar/UC09-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png)<br>[![UC09-TC01-dompet](./assets/layar/UC09-TC01-dompet.png)](./assets/layar/UC09-TC01-dompet.png)<br>[Vitest · transaksi-pemeriksaan](./assets/layar/integration-transaksi-pemeriksaan.png) |
| UC09-TC02 | [![UC09-TC02](./assets/layar/UC09-TC02.png)](./assets/layar/UC09-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC09-TC03 | [![UC09-TC03](./assets/layar/UC09-TC03.png)](./assets/layar/UC09-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC10-TC01 | [![UC10-TC01](./assets/layar/UC10-TC01.png)](./assets/layar/UC10-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC10-TC02 | [![UC10-TC02](./assets/layar/UC10-TC02.png)](./assets/layar/UC10-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC10-TC03 | [![UC10-TC03](./assets/layar/UC10-TC03.png)](./assets/layar/UC10-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC11-TC01 | [![UC11-TC01](./assets/layar/UC11-TC01.png)](./assets/layar/UC11-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png)<br>[![UC11-TC01-form](./assets/layar/UC11-TC01-form.png)](./assets/layar/UC11-TC01-form.png)<br>[Vitest · profil](./assets/layar/integration-profil.png) |
| UC11-TC02 | [![UC11-TC02](./assets/layar/UC11-TC02.png)](./assets/layar/UC11-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC11-TC03 | [![UC11-TC03](./assets/layar/UC11-TC03.png)](./assets/layar/UC11-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC12-TC01 | [![UC12-TC01](./assets/layar/UC12-TC01.png)](./assets/layar/UC12-TC01.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png)<br>[Vitest · sengketa-putusan](./assets/layar/integration-sengketa-putusan.png) |
| UC12-TC02 | [![UC12-TC02](./assets/layar/UC12-TC02.png)](./assets/layar/UC12-TC02.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC12-TC03 | [![UC12-TC03](./assets/layar/UC12-TC03.png)](./assets/layar/UC12-TC03.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| UC12-TC04 | [![UC12-TC04](./assets/layar/UC12-TC04.png)](./assets/layar/UC12-TC04.png)<br>[Hasil asersi Playwright](./assets/layar/playwright-9.png) |
| KNF01-TC01 | [Vitest · auth-flow](./assets/layar/integration-auth-flow.png) |
| KNF02-TC01 | [Vitest · verifikasi](./assets/layar/integration-verifikasi.png) |
| KNF03-TC01 | [![pengukuran](./assets/layar/pengukuran.png)](./assets/layar/pengukuran.png) |
| KNF04-TC01 | [![pengukuran](./assets/layar/pengukuran.png)](./assets/layar/pengukuran.png) |
| KNF05-TC01 | [Formulir ponsel](./assets/layar/KNF05-penawaran-ponsel.png)<br>[Tinjauan ponsel](./assets/layar/KNF05-tinjau-ponsel.png) |
| KNF06-TC01 | [Vitest · pilih-pelamar](./assets/layar/integration-pilih-pelamar.png) |
| KNF07-TC01 | [Vitest · domain-lintas](./assets/layar/integration-domain-lintas.png) |
| KNF08-TC01 | [Pengukuran heap JavaScript](./assets/layar/pengukuran.png) |
| KNF09-TC01 | [Checkbox ponsel](./assets/layar/KNF09-checkbox-ponsel.png)<br>[Checkbox desktop](./assets/layar/KNF09-checkbox-desktop.png)<br>[Uji integrasi lowongan](./assets/layar/integration-lowongan.png) |
| KNF10-TC01 | Belum ada bukti pemantauan bulanan. |
| KNF11-TC01 | [Vitest · pembayaran-saldo](./assets/layar/integration-pembayaran-saldo.png) |
| KNF12-TC01 | Tidak ada pengukuran TLS eksternal pada Payment Gateway dummy lokal. |
| KNF13-TC01 | [![pengukuran](./assets/layar/pengukuran.png)](./assets/layar/pengukuran.png) |
| KNF14-TC01 | [Vitest · transaksi-bukti](./assets/layar/integration-transaksi-bukti.png) |
| KNF15-TC01 | [Vitest · transaksi-pemeriksaan](./assets/layar/integration-transaksi-pemeriksaan.png) |
| KNF16-TC01 | [Vitest · pencairan-retry](./assets/layar/integration-pencairan-retry.png) |
| KNF17-TC01 | [Vitest · rekening](./assets/layar/integration-rekening.png) |
| KNF18-TC01 | [![pengukuran](./assets/layar/pengukuran.png)](./assets/layar/pengukuran.png) |
| KNF19-TC01 | [Vitest · tiket-sengketa](./assets/layar/integration-tiket-sengketa.png) |
| KNF20-TC01 | [Vitest · db](./assets/layar/integration-db.png) |
| KNF21-TC01 | [Registrasi ponsel](./assets/layar/KNF21-daftar-ponsel.png)<br>[Lowongan ponsel](./assets/layar/KNF21-lowongan-ponsel.png)<br>[Penawaran ponsel](./assets/layar/KNF05-penawaran-ponsel.png)<br>[Registrasi desktop](./assets/layar/KNF21-daftar-desktop.png)<br>[Lowongan desktop](./assets/layar/KNF21-lowongan-desktop.png)<br>[Penawaran desktop](./assets/layar/KNF05-penawaran-desktop.png)<br>[Tinjauan desktop](./assets/layar/KNF05-tinjau-desktop.png) |
| KNF22-TC01 | [Vitest · batas unggah bukti](./assets/layar/integration-transaksi-bukti.png) |
| KNF23-TC01 | Belum ada bukti pengukuran uptime. |

<br>

---

# BAB 5: Traceability

Tabel 5.1. Matriks Kerunutan KF terhadap Implementasi dan Pengujian

| KF ID | KNF Terkait | Use Case ID | Kelas Terkait | Implementasi File Terkait | Test Case (UC) | Test Case (Unit/Integrasi/KNF) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| KF01 | KNF21 | UC01 | C01 – Pengguna<br>C16 – PenggunaUI<br>C31 – PenggunaController | `src/models/Pengguna.ts`<br>`src/app/daftar/page.tsx`<br>`src/controllers/PenggunaController.ts` | UC01-TC01, UC01-TC03 | C01-UT01, C01-UT02, C01-UT03, C01-UT04, C01-UT05, C01-UT06, C01-UT07, C01-UT08, C01-UT09, C01-UT10, C01-UT11, C01-UT12, C01-UT13, C01-UT14, C01-UT15, C01-UT16, C01-UT17, C01-UT18, C01-UT19, C01-UT20, C01-UT21, C01-UT22, C01-UT23, C01-UT24, INT-TC01, INT-TC02, KNF21-TC01 |
| KF02 | — | UC01 | C01 – Pengguna<br>C16 – PenggunaUI<br>C31 – PenggunaController | `src/models/Pengguna.ts`<br>`src/app/daftar/page.tsx`<br>`src/controllers/PenggunaController.ts` | UC01-TC01, UC01-TC02 | C01-UT01, C01-UT02, C01-UT03, C01-UT04, C01-UT05, C01-UT06, C01-UT07, C01-UT08, C01-UT09, C01-UT10, C01-UT11, C01-UT12, C01-UT13, C01-UT14, C01-UT15, C01-UT16, C01-UT17, C01-UT18, C01-UT19, C01-UT20, C01-UT21, C01-UT22, C01-UT23, C01-UT24, INT-TC01, INT-TC02 |
| KF03 | KNF01 | UC01 | C01 – Pengguna<br>C16 – PenggunaUI<br>C31 – PenggunaController | `src/models/Pengguna.ts`<br>`src/app/daftar/page.tsx`<br>`src/controllers/PenggunaController.ts` | UC01-TC01 | C01-UT01, C01-UT02, C01-UT03, C01-UT04, C01-UT05, C01-UT06, C01-UT07, C01-UT08, C01-UT09, C01-UT10, C01-UT11, C01-UT12, C01-UT13, C01-UT14, C01-UT15, C01-UT16, C01-UT17, C01-UT18, C01-UT19, C01-UT20, C01-UT21, C01-UT22, C01-UT23, C01-UT24, INT-TC01, INT-TC02, KNF01-TC01 |
| KF04 | KNF02, KNF22 | UC02 | C02 – TenagaKerja<br>C17 – TenagaKerjaUI<br>C19 – CustomerServiceUI<br>C32 – TenagaKerjaController<br>C34 – CustomerServiceController | `src/models/TenagaKerja.ts`<br>`src/app/tk/page.tsx`<br>`src/app/cs/page.tsx`<br>`src/controllers/TenagaKerjaController.ts`<br>`src/controllers/CustomerServiceController.ts` | UC02-TC01, UC02-TC02 | INT-TC04, INT-TC05, KNF02-TC01, KNF22-TC01 |
| KF05 | — | UC02 | C02 – TenagaKerja<br>C17 – TenagaKerjaUI<br>C19 – CustomerServiceUI<br>C32 – TenagaKerjaController<br>C34 – CustomerServiceController | `src/models/TenagaKerja.ts`<br>`src/app/tk/page.tsx`<br>`src/app/cs/page.tsx`<br>`src/controllers/TenagaKerjaController.ts`<br>`src/controllers/CustomerServiceController.ts`<br>Persetujuan manual tersedia; tautan verifikasi email belum dibuktikan. | UC02-TC01, UC02-TC03 | INT-TC04, INT-TC05 |
| KF06 | KNF03, KNF23 | UC02 | C02 – TenagaKerja<br>C17 – TenagaKerjaUI<br>C19 – CustomerServiceUI<br>C32 – TenagaKerjaController<br>C34 – CustomerServiceController | `src/models/TenagaKerja.ts`<br>`src/app/tk/page.tsx`<br>`src/app/cs/page.tsx`<br>`src/controllers/TenagaKerjaController.ts`<br>`src/controllers/CustomerServiceController.ts` | UC02-TC01, UC02-TC03, UC02-TC04 | INT-TC04, INT-TC05, KNF03-TC01, KNF23-TC01 |
| KF07 | KNF05, KNF09, KNF10 | UC03 | C05 – LowonganPekerjaan<br>C18 – PenyediaKerjaUI<br>C35 – LowonganPekerjaanController | `src/models/LowonganPekerjaan.ts`<br>`src/app/pk/page.tsx`<br>`src/controllers/LowonganPekerjaanController.ts` | UC03-TC01, UC03-TC03 | INT-TC06, INT-TC07, KNF05-TC01, KNF09-TC01, KNF10-TC01 |
| KF08 | KNF09, KNF10 | UC03 | C05 – LowonganPekerjaan<br>C18 – PenyediaKerjaUI<br>C35 – LowonganPekerjaanController | `src/models/LowonganPekerjaan.ts`<br>`src/app/pk/page.tsx`<br>`src/controllers/LowonganPekerjaanController.ts` | UC03-TC02 | INT-TC06, INT-TC07, KNF09-TC01, KNF10-TC01 |
| KF09 | KNF04, KNF08, KNF10, KNF21 | UC04 | C05 – LowonganPekerjaan<br>C20 – LowonganPekerjaanUI<br>C35 – LowonganPekerjaanController | `src/models/LowonganPekerjaan.ts`<br>`src/app/lowongan/page.tsx`<br>`src/controllers/LowonganPekerjaanController.ts` | UC04-TC01, UC04-TC02 | INT-TC06, INT-TC07, KNF04-TC01, KNF21-TC01, KNF08-TC01, KNF10-TC01 |
| KF10 | KNF05, KNF10 | UC05 | C02 – TenagaKerja<br>C06 – PengajuanPenawaran<br>C21 – PengajuanPenawaranUI<br>C36 – PengajuanPenawaranController | `src/models/TenagaKerja.ts`<br>`src/models/PengajuanPenawaran.ts`<br>`src/views/penawaran/DialogPenawaran.tsx`<br>`src/controllers/PengajuanPenawaranController.ts` | UC05-TC01, UC05-TC02 | INT-TC04, INT-TC05, INT-TC08, INT-TC09, INT-TC10, KNF05-TC01, KNF10-TC01 |
| KF11 | KNF10 | UC05 | C02 – TenagaKerja<br>C06 – PengajuanPenawaran<br>C21 – PengajuanPenawaranUI<br>C36 – PengajuanPenawaranController | `src/models/TenagaKerja.ts`<br>`src/models/PengajuanPenawaran.ts`<br>`src/views/penawaran/DialogPenawaran.tsx`<br>`src/controllers/PengajuanPenawaranController.ts` | UC05-TC01, UC05-TC03 | INT-TC04, INT-TC05, INT-TC08, INT-TC09, INT-TC10, KNF10-TC01 |
| KF12 | KNF06, KNF07, KNF08, KNF10, KNF21, KNF23 | UC06 | C05 – LowonganPekerjaan<br>C06 – PengajuanPenawaran<br>C07 – TransaksiPekerjaan<br>C21 – PengajuanPenawaranUI<br>C36 – PengajuanPenawaranController | `src/models/LowonganPekerjaan.ts`<br>`src/models/PengajuanPenawaran.ts`<br>`src/models/TransaksiPekerjaan.ts`<br>`src/views/penawaran/DialogPenawaran.tsx`<br>`src/controllers/PengajuanPenawaranController.ts` | UC06-TC01, UC06-TC02, UC06-TC03 | INT-TC06, INT-TC07, INT-TC08, INT-TC09, INT-TC10, C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, KNF06-TC01, KNF07-TC01, KNF21-TC01, KNF08-TC01, KNF10-TC01, KNF23-TC01 |
| KF13 | KNF07, KNF10 | UC06 | C05 – LowonganPekerjaan<br>C06 – PengajuanPenawaran<br>C07 – TransaksiPekerjaan<br>C21 – PengajuanPenawaranUI<br>C36 – PengajuanPenawaranController | `src/models/LowonganPekerjaan.ts`<br>`src/models/PengajuanPenawaran.ts`<br>`src/models/TransaksiPekerjaan.ts`<br>`src/views/penawaran/DialogPenawaran.tsx`<br>`src/controllers/PengajuanPenawaranController.ts` | UC06-TC01, UC06-TC02 | INT-TC06, INT-TC07, INT-TC08, INT-TC09, INT-TC10, C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, KNF07-TC01, KNF10-TC01 |
| KF14 | KNF10, KNF11, KNF12 | UC07 | C07 – TransaksiPekerjaan<br>C09 – TagihanPembayaran<br>C15 – PaymentGateway<br>C24 – TagihanPembayaranUI<br>C39 – TagihanPembayaranController<br>C45 – PaymentGatewayController | `src/models/TransaksiPekerjaan.ts`<br>`src/models/TagihanPembayaran.ts`<br>`src/controllers/PaymentGatewayController.ts`<br>`src/views/transaksi/TagihanPembayaranUI.tsx`<br>`src/controllers/TagihanPembayaranController.ts` | UC07-TC01, UC07-TC02, UC07-TC03 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, INT-TC16, INT-TC19, INT-TC17, C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13, KNF11-TC01, KNF10-TC01, KNF12-TC01 |
| KF15 | KNF10, KNF11, KNF12 | UC07 | C07 – TransaksiPekerjaan<br>C09 – TagihanPembayaran<br>C15 – PaymentGateway<br>C24 – TagihanPembayaranUI<br>C39 – TagihanPembayaranController<br>C45 – PaymentGatewayController | `src/models/TransaksiPekerjaan.ts`<br>`src/models/TagihanPembayaran.ts`<br>`src/controllers/PaymentGatewayController.ts`<br>`src/views/transaksi/TagihanPembayaranUI.tsx`<br>`src/controllers/TagihanPembayaranController.ts`<br>Status dan riwayat dicatat dari transaksi simulasi. | UC07-TC01, UC07-TC02, UC07-TC03 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, INT-TC16, INT-TC19, INT-TC17, C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13, KNF11-TC01, KNF10-TC01, KNF12-TC01 |
| KF16 | KNF13, KNF14, KNF22 | UC08 | C07 – TransaksiPekerjaan<br>C08 – BuktiPenyerahan<br>C23 – BuktiPenyerahanUI<br>C38 – BuktiPenyerahanController | `src/models/TransaksiPekerjaan.ts`<br>`src/models/BuktiPenyerahan.ts`<br>`src/views/transaksi/DetailTransaksi.tsx`<br>`src/controllers/TransaksiBuktiController.ts` | UC08-TC01, UC08-TC02, UC08-TC03 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, C08-UT01, C08-UT02, C08-UT03, C08-UT04, C08-UT05, C08-UT06, C08-UT07, C08-UT08, C08-UT09, INT-TC14, INT-TC15, KNF13-TC01, KNF14-TC01, KNF22-TC01 |
| KF17 | KNF15 | UC09 | C07 – TransaksiPekerjaan<br>C08 – BuktiPenyerahan<br>C14 – Notifikasi<br>C22 – TransaksiPekerjaanUI<br>C37 – TransaksiPekerjaanController<br>C44 – NotifikasiController | `src/models/TransaksiPekerjaan.ts`<br>`src/models/BuktiPenyerahan.ts`<br>`src/models/Notifikasi.ts`<br>`src/views/transaksi/HalamanDaftarTransaksi.tsx`<br>`src/controllers/TransaksiPekerjaanController.ts`<br>`src/controllers/NotifikasiController.ts`<br>Penyelesaian otomatis mengkredit saldo; pencairan rekening diajukan terpisah. | UC09-TC01, UC09-TC02, UC09-TC03 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, C08-UT01, C08-UT02, C08-UT03, C08-UT04, C08-UT05, C08-UT06, C08-UT07, C08-UT08, C08-UT09, INT-TC14, INT-TC15, INT-TC29, KNF15-TC01 |
| KF18 | — | UC09 | C07 – TransaksiPekerjaan<br>C08 – BuktiPenyerahan<br>C14 – Notifikasi<br>C22 – TransaksiPekerjaanUI<br>C37 – TransaksiPekerjaanController<br>C44 – NotifikasiController | `src/models/TransaksiPekerjaan.ts`<br>`src/models/BuktiPenyerahan.ts`<br>`src/models/Notifikasi.ts`<br>`src/views/transaksi/HalamanDaftarTransaksi.tsx`<br>`src/controllers/TransaksiPekerjaanController.ts`<br>`src/controllers/NotifikasiController.ts` | UC09-TC01 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, C08-UT01, C08-UT02, C08-UT03, C08-UT04, C08-UT05, C08-UT06, C08-UT07, C08-UT08, C08-UT09, INT-TC14, INT-TC15, INT-TC29 |
| KF19 | KNF16, KNF17 | UC10 | C10 – PencairanDana<br>C15 – PaymentGateway<br>C25 – PencairanDanaUI<br>C40 – PencairanDanaController<br>C45 – PaymentGatewayController | `src/models/PencairanDana.ts`<br>`src/controllers/PaymentGatewayController.ts`<br>`src/views/dompet/HalamanDompet.tsx`<br>`src/controllers/DompetController.ts`<br>Instruksi pencairan diproses oleh Payment Gateway dummy. | UC10-TC01, UC10-TC02, UC10-TC03 | INT-TC22, INT-TC23, INT-TC24, C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13, INT-TC19, C40-UT01, C40-UT02, C40-UT03, KNF16-TC01, KNF17-TC01 |
| KF20 | KNF16, KNF17 | UC10 | C10 – PencairanDana<br>C15 – PaymentGateway<br>C25 – PencairanDanaUI<br>C40 – PencairanDanaController<br>C45 – PaymentGatewayController | `src/models/PencairanDana.ts`<br>`src/controllers/PaymentGatewayController.ts`<br>`src/views/dompet/HalamanDompet.tsx`<br>`src/controllers/DompetController.ts` | UC10-TC01 | INT-TC22, INT-TC23, INT-TC24, C15-UT01, C15-UT04, C15-UT05, C15-UT06, C15-UT07, C15-UT08, C15-UT09, C15-UT10, C15-UT11, C15-UT12, C15-UT13, INT-TC19, C40-UT01, C40-UT02, C40-UT03, KNF16-TC01, KNF17-TC01 |
| KF21 | — | UC11 | C07 – TransaksiPekerjaan<br>C11 – UlasanRating<br>C26 – UlasanRatingUI<br>C37 – TransaksiPekerjaanController<br>C41 – UlasanRatingController | `src/models/TransaksiPekerjaan.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/views/transaksi/FormUlasanTransaksi.tsx`<br>`src/controllers/TransaksiPekerjaanController.ts` | UC11-TC01, UC11-TC03 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, INT-TC25 |
| KF22 | — | UC11 | C07 – TransaksiPekerjaan<br>C11 – UlasanRating<br>C26 – UlasanRatingUI<br>C37 – TransaksiPekerjaanController<br>C41 – UlasanRatingController | `src/models/TransaksiPekerjaan.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/views/transaksi/FormUlasanTransaksi.tsx`<br>`src/controllers/TransaksiPekerjaanController.ts` | UC11-TC02 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, INT-TC25 |
| KF23 | KNF18 | UC11 | C07 – TransaksiPekerjaan<br>C11 – UlasanRating<br>C26 – UlasanRatingUI<br>C37 – TransaksiPekerjaanController<br>C41 – UlasanRatingController | `src/models/TransaksiPekerjaan.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/views/transaksi/FormUlasanTransaksi.tsx`<br>`src/controllers/TransaksiPekerjaanController.ts` | UC11-TC01 | C07-UT01, C07-UT02, C07-UT03, C07-UT04, C07-UT05, C07-UT06, C07-UT07, C07-UT08, C07-UT09, C07-UT10, INT-TC11, INT-TC12, INT-TC25, KNF18-TC01 |
| KF24 | — | UC12 | C12 – TiketSengketa<br>C13 – RiwayatSengketa<br>C19 – CustomerServiceUI<br>C27 – TiketSengketaUI<br>C42 – TiketSengketaController<br>C43 – RiwayatSengketaController | `src/models/TiketSengketa.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/app/cs/page.tsx`<br>`src/app/tiket/[id]/page.tsx`<br>`src/controllers/TiketSengketaController.ts` | UC12-TC01, UC12-TC04 | INT-TC26, INT-TC27 |
| KF25 | — | UC12 | C12 – TiketSengketa<br>C13 – RiwayatSengketa<br>C19 – CustomerServiceUI<br>C27 – TiketSengketaUI<br>C42 – TiketSengketaController<br>C43 – RiwayatSengketaController | `src/models/TiketSengketa.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/app/cs/page.tsx`<br>`src/app/tiket/[id]/page.tsx`<br>`src/controllers/TiketSengketaController.ts` | UC12-TC01 | INT-TC26, INT-TC27 |
| KF26 | KNF19, KNF20 | UC12 | C12 – TiketSengketa<br>C13 – RiwayatSengketa<br>C19 – CustomerServiceUI<br>C27 – TiketSengketaUI<br>C42 – TiketSengketaController<br>C43 – RiwayatSengketaController | `src/models/TiketSengketa.ts`<br>`src/db/migrations/0001_init.sql`<br>`src/app/cs/page.tsx`<br>`src/app/tiket/[id]/page.tsx`<br>`src/controllers/TiketSengketaController.ts` | UC12-TC01, UC12-TC02, UC12-TC03, UC12-TC04 | INT-TC26, INT-TC27, KNF19-TC01, KNF20-TC01 |

Tabel 5.2. Matriks Kerunutan KNF terhadap Pengujian

| ID KNF | Parameter | KF/UC Terkait | Test Case |
| :--- | :--- | :--- | :--- |
| KNF01 | Security | KF03 / UC01 | KNF01-TC01 |
| KNF02 | Security | KF04 / UC02 | KNF02-TC01 |
| KNF03 | Response time | KF06 / UC02 | KNF03-TC01 |
| KNF04 | Response Time | KF09 / UC04 | KNF04-TC01 |
| KNF05 | Ergonomy | KF07 / UC03, KF10 / UC05 | KNF05-TC01 |
| KNF06 | Security | KF12 / UC06 | KNF06-TC01 |
| KNF07 | Reliability | KF12 / UC06, KF13 / UC06 | KNF07-TC01 |
| KNF08 | Memory | KF09 / UC04, KF12 / UC06 | KNF08-TC01 |
| KNF09 | Safety | KF07 / UC03, KF08 / UC03 | KNF09-TC01 |
| KNF10 | Availability | KF07 / UC03, KF08 / UC03, KF09 / UC04, KF10 / UC05, KF11 / UC05, KF12 / UC06, KF13 / UC06, KF14 / UC07, KF15 / UC07 | KNF10-TC01 |
| KNF11 | Reliability | KF14 / UC07, KF15 / UC07 | KNF11-TC01 |
| KNF12 | Security | KF14 / UC07, KF15 / UC07 | KNF12-TC01 |
| KNF13 | Response Time | KF16 / UC08 | KNF13-TC01 |
| KNF14 | Security | KF16 / UC08 | KNF14-TC01 |
| KNF15 | Reliability | KF17 / UC09 | KNF15-TC01 |
| KNF16 | Reliability | KF19 / UC10, KF20 / UC10 | KNF16-TC01 |
| KNF17 | Security | KF19 / UC10, KF20 / UC10 | KNF17-TC01 |
| KNF18 | Response time | KF23 / UC11 | KNF18-TC01 |
| KNF19 | Security | KF26 / UC12 | KNF19-TC01 |
| KNF20 | Reliability | KF26 / UC12 | KNF20-TC01 |
| KNF21 | Portability | KF01 / UC01, KF09 / UC04, KF12 / UC06 | KNF21-TC01 |
| KNF22 | Memory | KF04 / UC02, KF16 / UC08 | KNF22-TC01 |
| KNF23 | Availability | KF06 / UC02, KF12 / UC06 | KNF23-TC01 |
